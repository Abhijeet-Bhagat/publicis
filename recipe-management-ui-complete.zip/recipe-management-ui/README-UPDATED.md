# Recipe Management UI

A modern Angular frontend application for managing recipes, built with Angular 20 and Angular Material. This application provides a comprehensive recipe management interface with search, filtering, pagination, and detailed recipe views.

## 🚀 Features

- **Recipe Browse & Search**: Search and browse through recipes with real-time filtering
- **Recipe Details**: View detailed recipe information including ingredients, instructions, and nutritional data
- **Responsive Design**: Mobile-first responsive design using Angular Material and Bootstrap
- **Pagination**: Efficient pagination for large recipe collections
- **Modern UI**: Clean, modern interface with Material Design components
- **Dummy Data**: Pre-loaded with sample recipes for testing and development

## 📋 Prerequisites

- Node.js version 22 or higher
- npm or yarn package manager

## 🛠️ Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd recipe-management-ui
```

2. Install dependencies:
```bash
npm install
```

## 🏃‍♂️ Running the Application

### Development Server (with Dummy Data)
```bash
npm start
```
The application will be available at `http://localhost:4200`

### Production Build
```bash
npm run build
```

### Testing
```bash
npm test
```

### Linting
```bash
npm run lint
```

## 🎯 Current Configuration

The application is currently configured to use **dummy data** for testing and development purposes. This includes:

- **6 sample recipes** with various cuisines (Italian, Indian, Mediterranean, Asian, American, Greek)
- **Mock API responses** with realistic data structure
- **Simulated loading delays** to test UI behavior
- **Full search functionality** working with sample data

### Sample Recipes Included:
1. **Classic Margherita Pizza** - Italian cuisine
2. **Chicken Tikka Masala** - Indian cuisine  
3. **Caesar Salad** - Mediterranean cuisine
4. **Beef Stir Fry** - Asian cuisine
5. **Chocolate Chip Cookies** - American cuisine
6. **Greek Salad** - Greek cuisine

## 🔧 Switching to Real API

To connect to a real backend API, modify the `src/app/app.config.ts` file:

```typescript
// Remove this line for real API
{ provide: RecipeService, useClass: MockRecipeService }

// Update environment files with your API URL
// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://your-api-url/api/v1'
};
```

## 📱 Testing the Application

### Manual Testing Guide:

1. **Search Functionality**:
   - Try searching for "pizza", "chicken", "salad"
   - Test search with cuisine names: "Italian", "Indian", "Greek"
   - Test search with ingredients: "tomato", "cheese", "garlic"

2. **Recipe Details**:
   - Click on any recipe card to view detailed information
   - Test all tabs: Ingredients, Instructions, Details
   - Verify recipe information displays correctly

3. **Pagination**:
   - Navigate between pages using pagination controls
   - Test page size limits (currently set to 12 items per page)

4. **Responsive Design**:
   - Test on different screen sizes
   - Verify mobile-friendly layout
   - Check tablet and desktop views

### Automated Testing:
```bash
# Run the test script
./test-app.sh
```

## 🏗️ Architecture

### Project Structure:
```
src/
├── app/
│   ├── core/
│   │   ├── models/          # Data models and interfaces
│   │   └── services/        # Business logic and API services
│   ├── shared/
│   │   └── components/      # Reusable UI components
│   ├── environments/        # Environment configurations
│   └── styles/             # Global styles and themes
```

### Key Components:
- **RecipeCardComponent**: Displays recipe summary cards
- **SearchBarComponent**: Handles search input and filtering
- **PaginationComponent**: Manages page navigation
- **RecipeDetailModalComponent**: Shows detailed recipe information
- **LoadingSpinnerComponent**: Provides loading feedback

### Services:
- **RecipeService**: Handles recipe data operations
- **MockRecipeService**: Provides dummy data for testing
- **DataService**: Manages data loading and caching

## 🎨 Styling

The application uses:
- **Angular Material**: For consistent Material Design components
- **Bootstrap**: For responsive grid system and utilities
- **SCSS**: For advanced styling features
- **Custom CSS**: For specific component styling

## 🔧 Configuration

### Environment Variables:
```typescript
// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api/v1'
};
```

### Angular Configuration:
- **Angular 20**: Latest stable version
- **TypeScript**: Strict mode enabled
- **ESLint**: Code quality and consistency
- **Karma + Jasmine**: Unit testing framework

## 🚀 Deployment

### Local Development:
```bash
npm start
```

### Production Build:
```bash
npm run build
# Serve from dist/recipe-management-ui/
```

### Docker Deployment:
```dockerfile
# Example Dockerfile (create this file)
FROM nginx:alpine
COPY dist/recipe-management-ui/ /usr/share/nginx/html/
EXPOSE 80
```

## 🐛 Debugging

### Common Issues:

1. **Port Already in Use**:
   ```bash
   ng serve --port 4201
   ```

2. **Build Errors**:
   ```bash
   npm run build -- --verbose
   ```

3. **Test Failures**:
   ```bash
   npm test -- --watch=false --browsers=ChromeHeadless
   ```

### Debug Features:
- **Browser Developer Tools**: Full source maps available
- **Angular DevTools**: Compatible with Angular DevTools extension
- **Console Logging**: Detailed error logging in development mode

## 🔍 Monitoring

The application includes:
- **Error Handling**: Comprehensive error handling with user-friendly messages
- **Loading States**: Visual feedback during data operations
- **Performance Monitoring**: Built-in Angular performance monitoring

## 📞 Support

For development questions or issues:
1. Check the console for error messages
2. Verify all dependencies are installed correctly
3. Ensure Node.js version compatibility
4. Check the browser console for runtime errors

## 🎯 Next Steps

### Integration with Real API:
1. Remove mock service configuration
2. Update environment files with real API URLs
3. Test API integration
4. Add authentication if required

### Additional Features to Consider:
- User authentication and profiles
- Recipe favorites and collections
- Recipe creation and editing
- Advanced filtering and sorting
- Recipe sharing and social features
- Offline support with service workers

---

**Note**: This application is currently running with dummy data for testing purposes. All recipes and data are simulated for demonstration and development.
