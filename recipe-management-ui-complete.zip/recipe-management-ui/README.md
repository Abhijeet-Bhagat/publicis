# Recipe Management UI

A modern Angular frontend application for managing and browsing recipes, built with Angular 20, Angular Material, and Bootstrap.

## Features

- 🔍 **Recipe Search**: Real-time search with debounced input
- 📱 **Responsive Design**: Mobile-first, responsive layout
- 🎨 **Modern UI**: Clean, Material Design interface
- 📄 **Pagination**: Efficient browsing of large recipe collections
- 🔍 **Recipe Details**: Comprehensive recipe information modal
- ⚡ **Performance**: Optimized loading and caching
- 🛠 **Data Management**: Load and refresh recipe data from API

## Prerequisites

Before running this application, ensure you have:

1. **Node.js** (version 20.19.0 or higher)
2. **npm** (version 8.0.0 or higher)
3. **Angular CLI** (installed globally)
4. **Recipe Management Backend** running on `http://localhost:8080`

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Start Development Server

```bash
ng serve
```

The application will be available at `http://localhost:4200`

### 3. Load Recipe Data

Once the application loads:
1. Click the "Load Recipe Data" button in the toolbar
2. This will fetch sample recipes from the backend API
3. Start searching and browsing recipes!

## Backend API Integration

This frontend integrates with the Recipe Management API backend. Ensure the backend is running on `http://localhost:8080` before using the application.

### API Endpoints Used

- `GET /api/v1/recipes/search` - Search recipes with pagination
- `GET /api/v1/recipes/{id}` - Get recipe by ID
- `GET /api/v1/recipes` - Get all recipes with pagination
- `POST /api/v1/data/load` - Load recipe data from external source
- `GET /api/v1/data/status` - Check data status
- `POST /api/v1/data/refresh` - Refresh recipe data

## Project Structure

```
src/
├── app/
│   ├── core/
│   │   ├── models/          # TypeScript interfaces
│   │   └── services/        # HTTP services
│   ├── shared/
│   │   └── components/      # Reusable components
│   │       ├── recipe-card/
│   │       ├── search-bar/
│   │       ├── pagination/
│   │       ├── loading-spinner/
│   │       └── recipe-detail-modal/
│   ├── app.ts              # Main app component
│   ├── app.html            # Main app template
│   └── app.scss            # Main app styles
├── environments/           # Environment configurations
└── styles.scss            # Global styles
```

## Technologies Used

- **Angular 20** - Frontend framework
- **Angular Material** - UI component library
- **Bootstrap** - CSS framework for responsive design
- **RxJS** - Reactive programming
- **TypeScript** - Type-safe JavaScript
- **SCSS** - Styled CSS preprocessing

## Development Commands

```bash
# Install dependencies
npm install

# Start development server
ng serve

# Build for production
ng build --prod

# Run tests
ng test

# Run end-to-end tests
ng e2e

# Lint code
ng lint
```

## License

This project is licensed under the MIT License.
