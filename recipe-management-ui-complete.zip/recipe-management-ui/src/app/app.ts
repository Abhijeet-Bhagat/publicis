import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { RecipeService } from './core/services/recipe.service';
import { DataService } from './core/services/data.service';
import { Recipe, RecipeSearchParams } from './core/models/recipe.model';
import { RecipeSearchResponse } from './core/models/api-response.model';
import { SearchBarComponent } from './shared/components/search-bar/search-bar.component';
import { RecipeCardComponent } from './shared/components/recipe-card/recipe-card.component';
import { LoadingSpinnerComponent } from './shared/components/loading-spinner/loading-spinner.component';
import { PaginationComponent } from './shared/components/pagination/pagination.component';
import { RecipeDetailModalComponent } from './shared/components/recipe-detail-modal/recipe-detail-modal.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    CommonModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    MatDialogModule,
    SearchBarComponent,
    RecipeCardComponent,
    LoadingSpinnerComponent,
    PaginationComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class AppComponent implements OnInit {
  title = 'recipe-management-ui';
  searchResults: RecipeSearchResponse | null = null;
  isLoading = false;
  currentSearchParams: RecipeSearchParams = { page: 0, size: 12 };

  constructor(
    private recipeService: RecipeService,
    private dataService: DataService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadInitialData();
  }

  loadInitialData(): void {
    this.isLoading = true;
    this.recipeService.getAllRecipes(0, 12).subscribe({
      next: (response) => {
        this.searchResults = response.data;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading recipes:', error);
        this.snackBar.open('Failed to load recipes. Please try again.', 'Close', {
          duration: 3000
        });
        this.isLoading = false;
      }
    });
  }

  onSearch(searchTerm: string): void {
    this.currentSearchParams = { ...this.currentSearchParams, searchTerm, page: 0 };
    this.performSearch();
  }

  onClearSearch(): void {
    this.currentSearchParams = { page: 0, size: 12 };
    this.loadInitialData();
  }

  onPageChange(page: number): void {
    this.currentSearchParams = { ...this.currentSearchParams, page };
    this.performSearch();
  }

  private performSearch(): void {
    this.isLoading = true;
    this.recipeService.searchRecipes(this.currentSearchParams).subscribe({
      next: (response) => {
        this.searchResults = response.data;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error searching recipes:', error);
        this.snackBar.open('Failed to search recipes. Please try again.', 'Close', {
          duration: 3000
        });
        this.isLoading = false;
      }
    });
  }

  loadData(): void {
    this.isLoading = true;
    this.dataService.loadRecipeData().subscribe({
      next: (response) => {
        this.snackBar.open('Recipe data loaded successfully!', 'Close', {
          duration: 3000
        });
        this.loadInitialData();
      },
      error: (error) => {
        console.error('Error loading data:', error);
        this.snackBar.open('Failed to load recipe data. Please try again.', 'Close', {
          duration: 3000
        });
        this.isLoading = false;
      }
    });
  }

  openRecipeDetail(recipe: Recipe): void {
    this.dialog.open(RecipeDetailModalComponent, {
      data: recipe,
      maxWidth: '90vw',
      maxHeight: '90vh'
    });
  }
}
