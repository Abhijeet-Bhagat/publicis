import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Recipe, RecipeSearchParams } from '../models/recipe.model';
import { ApiResponse, RecipeSearchResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class RecipeService {
  private readonly apiUrl = environment.apiUrl;
  private searchResultsSubject = new BehaviorSubject<RecipeSearchResponse | null>(null);
  public searchResults$ = this.searchResultsSubject.asObservable();

  constructor(private http: HttpClient) {}

  searchRecipes(params: RecipeSearchParams): Observable<ApiResponse<RecipeSearchResponse>> {
    let httpParams = new HttpParams();
    
    if (params.searchTerm) httpParams = httpParams.set('q', params.searchTerm);
    if (params.page !== undefined) httpParams = httpParams.set('page', params.page.toString());
    if (params.size !== undefined) httpParams = httpParams.set('size', params.size.toString());

    return this.http.get<ApiResponse<RecipeSearchResponse>>(`${this.apiUrl}/recipes/search`, { params: httpParams });
  }

  getRecipeById(id: number): Observable<ApiResponse<Recipe>> {
    return this.http.get<ApiResponse<Recipe>>(`${this.apiUrl}/recipes/${id}`);
  }

  getAllRecipes(page: number = 0, size: number = 20): Observable<ApiResponse<RecipeSearchResponse>> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    return this.http.get<ApiResponse<RecipeSearchResponse>>(`${this.apiUrl}/recipes`, { params });
  }

  updateSearchResults(results: RecipeSearchResponse): void {
    this.searchResultsSubject.next(results);
  }
}
