import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { Recipe, RecipeSearchParams } from '../models/recipe.model';
import { ApiResponse, RecipeSearchResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class MockRecipeService {
  private dummyRecipes: Recipe[] = [
    {
      id: 1,
      name: 'Classic Margherita Pizza',
      cuisine: 'Italian',
      difficulty: 'Easy',
      ingredients: [
        'Pizza dough',
        'Tomato sauce',
        'Fresh mozzarella cheese',
        'Fresh basil leaves',
        'Olive oil',
        'Salt and pepper'
      ],
      instructions: [
        'Preheat oven to 475°F (245°C)',
        'Roll out pizza dough on floured surface',
        'Spread tomato sauce evenly',
        'Add torn mozzarella pieces',
        'Bake for 12-15 minutes until crust is golden',
        'Top with fresh basil and drizzle with olive oil'
      ],
      prepTimeMinutes: 20,
      cookTimeMinutes: 15,
      servings: 4,
      caloriesPerServing: 285,
      tags: ['Pizza', 'Italian', 'Vegetarian', 'Classic'],
      rating: 4.8,
      reviewCount: 124,
      userId: 1,
      image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400&h=300&fit=crop',
      mealType: ['Dinner', 'Lunch']
    },
    {
      id: 2,
      name: 'Chicken Tikka Masala',
      cuisine: 'Indian',
      difficulty: 'Medium',
      ingredients: [
        '1 lb chicken breast, cubed',
        '1 cup heavy cream',
        '1 can tomato sauce',
        '2 tbsp tikka masala spice',
        '1 onion, diced',
        '3 garlic cloves, minced',
        '1 inch ginger, minced',
        'Basmati rice'
      ],
      instructions: [
        'Marinate chicken with spices for 30 minutes',
        'Cook chicken in hot oil until golden',
        'Sauté onion, garlic, and ginger',
        'Add tomato sauce and spices',
        'Simmer and add cream',
        'Return chicken to sauce',
        'Serve over basmati rice'
      ],
      prepTimeMinutes: 30,
      cookTimeMinutes: 25,
      servings: 6,
      caloriesPerServing: 420,
      tags: ['Curry', 'Indian', 'Spicy', 'Chicken'],
      rating: 4.6,
      reviewCount: 89,
      userId: 2,
      image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
      mealType: ['Dinner']
    },
    {
      id: 3,
      name: 'Caesar Salad',
      cuisine: 'Mediterranean',
      difficulty: 'Easy',
      ingredients: [
        '2 heads romaine lettuce',
        '1/2 cup parmesan cheese',
        '1/4 cup Caesar dressing',
        '1 cup croutons',
        '2 anchovy fillets (optional)',
        'Black pepper'
      ],
      instructions: [
        'Wash and chop romaine lettuce',
        'Toss with Caesar dressing',
        'Add croutons and parmesan',
        'Season with black pepper',
        'Serve immediately'
      ],
      prepTimeMinutes: 15,
      cookTimeMinutes: 0,
      servings: 4,
      caloriesPerServing: 180,
      tags: ['Salad', 'Quick', 'Vegetarian', 'Fresh'],
      rating: 4.3,
      reviewCount: 67,
      userId: 3,
      image: 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400&h=300&fit=crop',
      mealType: ['Lunch', 'Dinner']
    },
    {
      id: 4,
      name: 'Beef Stir Fry',
      cuisine: 'Asian',
      difficulty: 'Medium',
      ingredients: [
        '1 lb beef sirloin, sliced thin',
        '2 cups mixed vegetables',
        '3 tbsp soy sauce',
        '2 tbsp oyster sauce',
        '1 tbsp cornstarch',
        '2 cloves garlic, minced',
        '1 tbsp vegetable oil',
        'Rice for serving'
      ],
      instructions: [
        'Marinate beef with soy sauce and cornstarch',
        'Heat oil in wok or large pan',
        'Cook beef until browned, remove',
        'Stir fry vegetables until tender-crisp',
        'Return beef to pan',
        'Add sauces and toss',
        'Serve over rice'
      ],
      prepTimeMinutes: 20,
      cookTimeMinutes: 10,
      servings: 4,
      caloriesPerServing: 350,
      tags: ['Stir Fry', 'Asian', 'Quick', 'Healthy'],
      rating: 4.5,
      reviewCount: 112,
      userId: 4,
      image: 'https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=400&h=300&fit=crop',
      mealType: ['Dinner', 'Lunch']
    },
    {
      id: 5,
      name: 'Chocolate Chip Cookies',
      cuisine: 'American',
      difficulty: 'Easy',
      ingredients: [
        '2 1/4 cups all-purpose flour',
        '1 tsp baking soda',
        '1 tsp salt',
        '1 cup butter, softened',
        '3/4 cup granulated sugar',
        '3/4 cup brown sugar',
        '2 large eggs',
        '2 tsp vanilla extract',
        '2 cups chocolate chips'
      ],
      instructions: [
        'Preheat oven to 375°F (190°C)',
        'Mix flour, baking soda, and salt',
        'Cream butter and sugars',
        'Beat in eggs and vanilla',
        'Gradually add flour mixture',
        'Stir in chocolate chips',
        'Drop on baking sheet',
        'Bake 9-11 minutes'
      ],
      prepTimeMinutes: 15,
      cookTimeMinutes: 10,
      servings: 48,
      caloriesPerServing: 150,
      tags: ['Cookies', 'Dessert', 'Baking', 'Sweet'],
      rating: 4.9,
      reviewCount: 203,
      userId: 5,
      image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&h=300&fit=crop',
      mealType: ['Snack', 'Dessert']
    },
    {
      id: 6,
      name: 'Greek Salad',
      cuisine: 'Greek',
      difficulty: 'Easy',
      ingredients: [
        '4 large tomatoes, chopped',
        '1 cucumber, sliced',
        '1 red onion, thinly sliced',
        '1/2 cup kalamata olives',
        '200g feta cheese, cubed',
        '1/4 cup olive oil',
        '2 tbsp red wine vinegar',
        '1 tsp dried oregano',
        'Salt and pepper'
      ],
      instructions: [
        'Combine tomatoes, cucumber, and onion',
        'Add olives and feta cheese',
        'Whisk olive oil, vinegar, and oregano',
        'Dress salad and toss gently',
        'Season with salt and pepper',
        'Let sit for 10 minutes before serving'
      ],
      prepTimeMinutes: 15,
      cookTimeMinutes: 0,
      servings: 6,
      caloriesPerServing: 220,
      tags: ['Salad', 'Mediterranean', 'Fresh', 'Healthy'],
      rating: 4.4,
      reviewCount: 78,
      userId: 6,
      image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=300&fit=crop',
      mealType: ['Lunch', 'Dinner']
    }
  ];

  searchRecipes(params: RecipeSearchParams): Observable<ApiResponse<RecipeSearchResponse>> {
    // Simulate API delay
    return of(this.performSearch(params)).pipe(delay(500));
  }

  getRecipeById(id: number): Observable<ApiResponse<Recipe>> {
    const recipe = this.dummyRecipes.find(r => r.id === id);
    
    if (recipe) {
      return of({
        success: true,
        data: recipe,
        message: 'Recipe retrieved successfully',
        timestamp: new Date().toISOString()
      }).pipe(delay(300));
    } else {
      return of({
        success: false,
        data: null as any,
        message: 'Recipe not found',
        timestamp: new Date().toISOString()
      }).pipe(delay(300));
    }
  }

  getAllRecipes(page: number = 0, size: number = 20): Observable<ApiResponse<RecipeSearchResponse>> {
    const startIndex = page * size;
    const endIndex = startIndex + size;
    const paginatedRecipes = this.dummyRecipes.slice(startIndex, endIndex);
    
    const response: RecipeSearchResponse = {
      recipes: paginatedRecipes,
      pagination: {
        page: page,
        size: size,
        totalElements: this.dummyRecipes.length,
        totalPages: Math.ceil(this.dummyRecipes.length / size),
        hasNext: endIndex < this.dummyRecipes.length,
        hasPrevious: page > 0
      }
    };

    return of({
      success: true,
      data: response,
      message: 'Recipes retrieved successfully',
      timestamp: new Date().toISOString()
    }).pipe(delay(400));
  }

  private performSearch(params: RecipeSearchParams): ApiResponse<RecipeSearchResponse> {
    let filteredRecipes = [...this.dummyRecipes];

    // Apply search term filter
    if (params.searchTerm) {
      const searchLower = params.searchTerm.toLowerCase();
      filteredRecipes = filteredRecipes.filter(recipe =>
        recipe.name.toLowerCase().includes(searchLower) ||
        recipe.cuisine.toLowerCase().includes(searchLower) ||
        recipe.tags.some(tag => tag.toLowerCase().includes(searchLower)) ||
        recipe.ingredients.some(ingredient => ingredient.toLowerCase().includes(searchLower))
      );
    }

    // Apply pagination
    const page = params.page || 0;
    const size = params.size || 20;
    const startIndex = page * size;
    const endIndex = startIndex + size;
    const paginatedRecipes = filteredRecipes.slice(startIndex, endIndex);

    const response: RecipeSearchResponse = {
      recipes: paginatedRecipes,
      pagination: {
        page: page,
        size: size,
        totalElements: filteredRecipes.length,
        totalPages: Math.ceil(filteredRecipes.length / size),
        hasNext: endIndex < filteredRecipes.length,
        hasPrevious: page > 0
      },
      searchTerm: params.searchTerm
    };

    return {
      success: true,
      data: response,
      message: 'Search completed successfully',
      timestamp: new Date().toISOString()
    };
  }
}
