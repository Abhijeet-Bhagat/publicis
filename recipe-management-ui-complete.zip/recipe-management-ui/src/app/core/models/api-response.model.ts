export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

export interface PaginationInfo {
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  hasNext: boolean;
  hasPrevious: boolean;
}

export interface RecipeSearchResponse {
  recipes: Recipe[];
  pagination: PaginationInfo;
  searchTerm?: string;
  message?: string;
}

import { Recipe } from './recipe.model';
