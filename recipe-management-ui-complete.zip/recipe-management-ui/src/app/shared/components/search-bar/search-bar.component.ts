import { Component, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-search-bar',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatIconModule, MatButtonModule],
  template: `
    <div class="search-container">
      <mat-form-field appearance="outline" class="search-field">
        <mat-label>Search recipes...</mat-label>
        <input matInput 
               [formControl]="searchControl" 
               placeholder="Try 'pasta', 'Italian', 'chicken'..."
               (keyup.enter)="onSearch()">
        <mat-icon matSuffix>search</mat-icon>
      </mat-form-field>
      <button mat-raised-button 
              color="primary" 
              (click)="onSearch()"
              class="search-button">
        Search
      </button>
      <button mat-stroked-button 
              (click)="onClear()"
              class="clear-button">
        Clear
      </button>
    </div>
  `,
  styleUrls: ['./search-bar.component.scss']
})
export class SearchBarComponent implements OnInit, OnDestroy {
  @Output() search = new EventEmitter<string>();
  @Output() clear = new EventEmitter<void>();
  
  searchControl = new FormControl('');
  private destroy$ = new Subject<void>();

  ngOnInit(): void {
    this.searchControl.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe(value => {
        if (value && value.length > 2) {
          this.search.emit(value);
        } else if (value === '') {
          this.clear.emit();
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onSearch(): void {
    const value = this.searchControl.value;
    if (value) {
      this.search.emit(value);
    }
  }

  onClear(): void {
    this.searchControl.setValue('');
    this.clear.emit();
  }
}
