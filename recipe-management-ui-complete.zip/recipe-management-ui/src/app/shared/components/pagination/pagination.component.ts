import { Component, Input, Output, EventEmitter } from '@angular/core';
import { PaginationInfo } from '../../../core/models/api-response.model';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule],
  template: `
    <div class="pagination-container" *ngIf="pagination">
      <div class="pagination-info">
        <span>Page {{ pagination.page + 1 }} of {{ pagination.totalPages }}</span>
        <span class="total-items">{{ pagination.totalElements }} total items</span>
      </div>
      
      <div class="pagination-controls">
        <button mat-icon-button 
                [disabled]="!pagination.hasPrevious"
                (click)="onPageChange(0)"
                matTooltip="First Page">
          <mat-icon>first_page</mat-icon>
        </button>
        
        <button mat-icon-button 
                [disabled]="!pagination.hasPrevious"
                (click)="onPageChange(pagination.page - 1)"
                matTooltip="Previous Page">
          <mat-icon>chevron_left</mat-icon>
        </button>
        
        <div class="page-numbers">
          <button mat-button 
                  *ngFor="let pageNum of getPageNumbers()"
                  [class.active]="pageNum === pagination.page"
                  (click)="onPageChange(pageNum)">
            {{ pageNum + 1 }}
          </button>
        </div>
        
        <button mat-icon-button 
                [disabled]="!pagination.hasNext"
                (click)="onPageChange(pagination.page + 1)"
                matTooltip="Next Page">
          <mat-icon>chevron_right</mat-icon>
        </button>
        
        <button mat-icon-button 
                [disabled]="!pagination.hasNext"
                (click)="onPageChange(pagination.totalPages - 1)"
                matTooltip="Last Page">
          <mat-icon>last_page</mat-icon>
        </button>
      </div>
    </div>
  `,
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent {
  @Input() pagination!: PaginationInfo;
  @Output() pageChange = new EventEmitter<number>();

  onPageChange(page: number): void {
    if (page >= 0 && page < this.pagination.totalPages) {
      this.pageChange.emit(page);
    }
  }

  getPageNumbers(): number[] {
    const current = this.pagination.page;
    const total = this.pagination.totalPages;
    const delta = 2;
    
    const range = [];
    const rangeWithDots = [];
    
    for (let i = Math.max(0, current - delta); i <= Math.min(total - 1, current + delta); i++) {
      range.push(i);
    }
    
    if (range[0] > 0) {
      if (range[0] > 1) {
        rangeWithDots.push(0, -1);
      } else {
        rangeWithDots.push(0);
      }
    }
    
    rangeWithDots.push(...range);
    
    if (range[range.length - 1] < total - 1) {
      if (range[range.length - 1] < total - 2) {
        rangeWithDots.push(-1, total - 1);
      } else {
        rangeWithDots.push(total - 1);
      }
    }
    
    return rangeWithDots.filter(page => page >= 0);
  }
}
