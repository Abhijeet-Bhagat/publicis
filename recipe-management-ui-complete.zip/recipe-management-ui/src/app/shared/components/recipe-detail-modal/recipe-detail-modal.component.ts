import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { Recipe } from '../../../core/models/recipe.model';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-recipe-detail-modal',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule, MatChipsModule, MatTabsModule],
  template: `
    <div class="recipe-detail-modal">
      <div class="modal-header">
        <h2 mat-dialog-title>{{ recipe.name }}</h2>
        <button mat-icon-button (click)="close()" class="close-button">
          <mat-icon>close</mat-icon>
        </button>
      </div>
      
      <div mat-dialog-content class="modal-content">
        <div class="recipe-header">
          <img [src]="recipe.image" [alt]="recipe.name" class="recipe-image">
          <div class="recipe-info">
            <p class="cuisine">{{ recipe.cuisine }} Cuisine</p>
            <div class="rating">
              <mat-icon>star</mat-icon>
              <span>{{ recipe.rating }}/5 ({{ recipe.reviewCount }} reviews)</span>
            </div>
            <div class="quick-stats">
              <div class="stat">
                <mat-icon>schedule</mat-icon>
                <span>{{ recipe.prepTimeMinutes + recipe.cookTimeMinutes }} min</span>
              </div>
              <div class="stat">
                <mat-icon>people</mat-icon>
                <span>{{ recipe.servings }} servings</span>
              </div>
              <div class="stat">
                <mat-icon>local_fire_department</mat-icon>
                <span>{{ recipe.caloriesPerServing }} cal</span>
              </div>
            </div>
            <div class="difficulty-badge" [class]="'difficulty-' + recipe.difficulty.toLowerCase()">
              {{ recipe.difficulty }}
            </div>
          </div>
        </div>
        
        <mat-tab-group>
          <mat-tab label="Ingredients">
            <div class="tab-content">
              <ul class="ingredients-list">
                <li *ngFor="let ingredient of recipe.ingredients">
                  <mat-icon>check_circle_outline</mat-icon>
                  {{ ingredient }}
                </li>
              </ul>
            </div>
          </mat-tab>
          
          <mat-tab label="Instructions">
            <div class="tab-content">
              <ol class="instructions-list">
                <li *ngFor="let instruction of recipe.instructions">
                  {{ instruction }}
                </li>
              </ol>
            </div>
          </mat-tab>
          
          <mat-tab label="Details">
            <div class="tab-content">
              <div class="detail-grid">
                <div class="detail-item">
                  <strong>Prep Time:</strong>
                  <span>{{ recipe.prepTimeMinutes }} minutes</span>
                </div>
                <div class="detail-item">
                  <strong>Cook Time:</strong>
                  <span>{{ recipe.cookTimeMinutes }} minutes</span>
                </div>
                <div class="detail-item">
                  <strong>Total Time:</strong>
                  <span>{{ recipe.prepTimeMinutes + recipe.cookTimeMinutes }} minutes</span>
                </div>
                <div class="detail-item">
                  <strong>Servings:</strong>
                  <span>{{ recipe.servings }}</span>
                </div>
                <div class="detail-item">
                  <strong>Calories per Serving:</strong>
                  <span>{{ recipe.caloriesPerServing }}</span>
                </div>
                <div class="detail-item">
                  <strong>Meal Type:</strong>
                  <span>{{ recipe.mealType.join(', ') }}</span>
                </div>
              </div>
              
              <div class="tags-section">
                <h4>Tags</h4>
                <mat-chip-listbox>
                  <mat-chip *ngFor="let tag of recipe.tags">{{ tag }}</mat-chip>
                </mat-chip-listbox>
              </div>
            </div>
          </mat-tab>
        </mat-tab-group>
      </div>
    </div>
  `,
  styleUrls: ['./recipe-detail-modal.component.scss']
})
export class RecipeDetailModalComponent {
  constructor(
    public dialogRef: MatDialogRef<RecipeDetailModalComponent>,
    @Inject(MAT_DIALOG_DATA) public recipe: Recipe
  ) {}

  close(): void {
    this.dialogRef.close();
  }
}
