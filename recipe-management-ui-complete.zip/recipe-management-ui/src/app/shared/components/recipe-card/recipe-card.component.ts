import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Recipe } from '../../../core/models/recipe.model';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';

@Component({
  selector: 'app-recipe-card',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatButtonModule, MatIconModule, MatChipsModule],
  template: `
    <mat-card class="recipe-card" (click)="onCardClick()">
      <mat-card-header>
        <mat-card-title>{{ recipe.name }}</mat-card-title>
        <mat-card-subtitle>{{ recipe.cuisine }}</mat-card-subtitle>
      </mat-card-header>
      
      <img mat-card-image [src]="recipe.image" [alt]="recipe.name" class="recipe-image">
      
      <mat-card-content>
        <div class="recipe-info">
          <div class="info-item">
            <mat-icon>schedule</mat-icon>
            <span>{{ recipe.cookTimeMinutes }} min</span>
          </div>
          <div class="info-item">
            <mat-icon>star</mat-icon>
            <span>{{ recipe.rating }}/5</span>
          </div>
          <div class="info-item">
            <mat-icon>people</mat-icon>
            <span>{{ recipe.servings }} servings</span>
          </div>
          <div class="info-item">
            <mat-icon>local_fire_department</mat-icon>
            <span>{{ recipe.caloriesPerServing }} cal</span>
          </div>
        </div>
        
        <div class="tags">
          <mat-chip-listbox>
            <mat-chip *ngFor="let tag of recipe.tags.slice(0, 3)">{{ tag }}</mat-chip>
          </mat-chip-listbox>
        </div>
      </mat-card-content>
      
      <mat-card-actions>
        <button mat-raised-button color="primary" (click)="onViewDetails($event)">
          VIEW DETAILS
        </button>
        <div class="difficulty-badge" [class]="'difficulty-' + recipe.difficulty.toLowerCase()">
          {{ recipe.difficulty }}
        </div>
      </mat-card-actions>
    </mat-card>
  `,
  styleUrls: ['./recipe-card.component.scss']
})
export class RecipeCardComponent {
  @Input() recipe!: Recipe;
  @Output() viewDetails = new EventEmitter<Recipe>();
  @Output() cardClick = new EventEmitter<Recipe>();

  onViewDetails(event: Event): void {
    event.stopPropagation();
    this.viewDetails.emit(this.recipe);
  }

  onCardClick(): void {
    this.cardClick.emit(this.recipe);
  }
}
