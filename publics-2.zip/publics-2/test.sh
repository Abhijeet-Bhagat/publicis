#!/bin/bash

# Recipe Management API - Test Runner Script

echo "🧪 Recipe Management API Test Suite"
echo "===================================="

# Check if Maven is available
if ! command -v mvn &> /dev/null; then
    echo "❌ Maven is not installed. Please install Maven first."
    echo "   On macOS: brew install maven"
    echo "   On Ubuntu: sudo apt install maven"
    exit 1
fi

echo "📊 Running test suite..."
echo ""

# Run unit tests
echo "1️⃣ Running unit tests..."
mvn test -Dtest="*Test" -q

if [ $? -eq 0 ]; then
    echo "✅ Unit tests passed!"
else
    echo "❌ Unit tests failed!"
    exit 1
fi

echo ""

# Run integration tests
echo "2️⃣ Running integration tests..."
mvn test -Dtest="*ControllerTest" -q

if [ $? -eq 0 ]; then
    echo "✅ Integration tests passed!"
else
    echo "❌ Integration tests failed!"
    exit 1
fi

echo ""

# Generate test coverage report
echo "3️⃣ Generating test coverage report..."
mvn jacoco:report -q

if [ $? -eq 0 ]; then
    echo "✅ Test coverage report generated!"
    echo "   📄 View report at: target/site/jacoco/index.html"
else
    echo "❌ Failed to generate coverage report!"
fi

echo ""

# Run all tests with verification
echo "4️⃣ Running full verification..."
mvn clean verify -q

if [ $? -eq 0 ]; then
    echo "✅ All tests and verifications passed!"
    echo ""
    echo "🎉 Test suite completed successfully!"
    echo "   📈 Check target/site/jacoco/index.html for coverage details"
    echo "   📋 All components are working correctly"
else
    echo "❌ Verification failed!"
    exit 1
fi
