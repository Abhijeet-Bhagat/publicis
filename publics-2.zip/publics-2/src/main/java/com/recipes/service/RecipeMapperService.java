package com.recipes.service;

import com.recipes.dto.external.ExternalRecipeDto;
import com.recipes.dto.response.RecipeResponseDto;
import com.recipes.entity.Recipe;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Service for mapping between different recipe DTOs and entities
 * 
 * This service handles the conversion between external API DTOs,
 * internal entities, and response DTOs.
 */
@Service
public class RecipeMapperService {

    /**
     * Convert external recipe DTO to internal entity
     * 
     * @param externalDto External recipe DTO from API
     * @return Recipe entity
     */
    public Recipe toEntity(ExternalRecipeDto externalDto) {
        if (externalDto == null) {
            return null;
        }

        return Recipe.builder()
                .name(externalDto.getName())
                .ingredients(safeCopyList(externalDto.getIngredients()))
                .instructions(safeCopyList(externalDto.getInstructions()))
                .prepTimeMinutes(externalDto.getPrepTimeMinutes())
                .cookTimeMinutes(externalDto.getCookTimeMinutes())
                .servings(externalDto.getServings())
                .difficulty(externalDto.getDifficulty())
                .cuisine(externalDto.getCuisine())
                .caloriesPerServing(externalDto.getCaloriesPerServing())
                .tags(safeCopyList(externalDto.getTags()))
                .userId(externalDto.getUserId())
                .image(externalDto.getImage())
                .rating(externalDto.getRating())
                .reviewCount(externalDto.getReviewCount())
                .mealType(safeCopyList(externalDto.getMealType()))
                .build();
    }

    /**
     * Convert internal entity to response DTO
     * 
     * @param entity Recipe entity
     * @return Recipe response DTO
     */
    public RecipeResponseDto toResponseDto(Recipe entity) {
        if (entity == null) {
            return null;
        }

        return new RecipeResponseDto(
                entity.getId(),
                entity.getName(),
                safeCopyList(entity.getIngredients()),
                safeCopyList(entity.getInstructions()),
                entity.getPrepTimeMinutes(),
                entity.getCookTimeMinutes(),
                entity.getTotalTimeMinutes(),
                entity.getServings(),
                entity.getDifficulty(),
                entity.getCuisine(),
                entity.getCaloriesPerServing(),
                safeCopyList(entity.getTags()),
                entity.getUserId(),
                entity.getImage(),
                entity.getRating(),
                entity.getReviewCount(),
                safeCopyList(entity.getMealType())
        );
    }

    /**
     * Convert list of entities to list of response DTOs
     * 
     * @param entities List of recipe entities
     * @return List of recipe response DTOs
     */
    public List<RecipeResponseDto> toResponseDtoList(List<Recipe> entities) {
        if (entities == null) {
            return new ArrayList<>();
        }

        return entities.stream()
                .map(this::toResponseDto)
                .toList();
    }

    /**
     * Convert list of external DTOs to list of entities
     * 
     * @param externalDtos List of external recipe DTOs
     * @return List of recipe entities
     */
    public List<Recipe> toEntityList(List<ExternalRecipeDto> externalDtos) {
        if (externalDtos == null) {
            return new ArrayList<>();
        }

        return externalDtos.stream()
                .map(this::toEntity)
                .toList();
    }

    /**
     * Update existing entity with data from external DTO
     * 
     * @param existingEntity Existing recipe entity
     * @param externalDto External recipe DTO with updated data
     * @return Updated recipe entity
     */
    public Recipe updateEntity(Recipe existingEntity, ExternalRecipeDto externalDto) {
        if (existingEntity == null || externalDto == null) {
            return existingEntity;
        }

        // Update fields that might have changed
        existingEntity.setName(externalDto.getName());
        existingEntity.setIngredients(safeCopyList(externalDto.getIngredients()));
        existingEntity.setInstructions(safeCopyList(externalDto.getInstructions()));
        existingEntity.setPrepTimeMinutes(externalDto.getPrepTimeMinutes());
        existingEntity.setCookTimeMinutes(externalDto.getCookTimeMinutes());
        existingEntity.setServings(externalDto.getServings());
        existingEntity.setDifficulty(externalDto.getDifficulty());
        existingEntity.setCuisine(externalDto.getCuisine());
        existingEntity.setCaloriesPerServing(externalDto.getCaloriesPerServing());
        existingEntity.setTags(safeCopyList(externalDto.getTags()));
        existingEntity.setUserId(externalDto.getUserId());
        existingEntity.setImage(externalDto.getImage());
        existingEntity.setRating(externalDto.getRating());
        existingEntity.setReviewCount(externalDto.getReviewCount());
        existingEntity.setMealType(safeCopyList(externalDto.getMealType()));

        return existingEntity;
    }

    /**
     * Create a safe copy of a list, handling null values
     * 
     * @param originalList Original list to copy
     * @return Safe copy of the list
     */
    private List<String> safeCopyList(List<String> originalList) {
        if (originalList == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(originalList);
    }

    /**
     * Convert recipe entity to a summary DTO for listing
     * 
     * @param entity Recipe entity
     * @return Simplified recipe DTO for listing views
     */
    public RecipeResponseDto toSummaryDto(Recipe entity) {
        if (entity == null) {
            return null;
        }

        // Create a summary version with essential fields only
        RecipeResponseDto summary = new RecipeResponseDto();
        summary.setId(entity.getId());
        summary.setName(entity.getName());
        summary.setCuisine(entity.getCuisine());
        summary.setDifficulty(entity.getDifficulty());
        summary.setPrepTimeMinutes(entity.getPrepTimeMinutes());
        summary.setCookTimeMinutes(entity.getCookTimeMinutes());
        summary.setTotalTimeMinutes(entity.getTotalTimeMinutes());
        summary.setServings(entity.getServings());
        summary.setRating(entity.getRating());
        summary.setImage(entity.getImage());
        summary.setTags(safeCopyList(entity.getTags()));
        summary.setMealType(safeCopyList(entity.getMealType()));

        return summary;
    }

    /**
     * Convert list of entities to summary DTOs
     * 
     * @param entities List of recipe entities
     * @return List of summary DTOs
     */
    public List<RecipeResponseDto> toSummaryDtoList(List<Recipe> entities) {
        if (entities == null) {
            return new ArrayList<>();
        }

        return entities.stream()
                .map(this::toSummaryDto)
                .toList();
    }
}
