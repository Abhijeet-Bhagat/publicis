package com.recipes.service;

import com.recipes.dto.external.ExternalRecipeResponse;
import com.recipes.dto.response.RecipeResponseDto;
import com.recipes.dto.response.RecipeSearchResponseDto;
import com.recipes.entity.Recipe;
import com.recipes.repository.RecipeRepository;
import com.recipes.repository.RecipeSearchRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

/**
 * Main service for recipe management operations
 * 
 * This service provides business logic for recipe management including
 * loading data from external APIs, searching, and CRUD operations.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RecipeService {

    private final RecipeRepository recipeRepository;
    private final RecipeSearchRepository recipeSearchRepository;
    private final ExternalRecipeService externalRecipeService;
    private final RecipeMapperService mapperService;

    /**
     * Load all recipes from external API and save to database
     * 
     * @return Number of recipes loaded
     */
    @Transactional
    public int loadRecipesFromExternalApi() {
        log.info("Starting to load recipes from external API");
        
        try {
            // Clear existing data
            long existingCount = recipeRepository.count();
            if (existingCount > 0) {
                log.info("Clearing {} existing recipes before loading new data", existingCount);
                recipeRepository.deleteAll();
            }

            // Fetch data from external API
            ExternalRecipeResponse response = externalRecipeService.fetchAllRecipes();
            
            if (response == null || response.getRecipes() == null || response.getRecipes().isEmpty()) {
                log.warn("No recipes received from external API");
                return 0;
            }

            // Convert and save recipes
            List<Recipe> recipes = mapperService.toEntityList(response.getRecipes());
            List<Recipe> savedRecipes = recipeRepository.saveAll(recipes);
            
            log.info("Successfully loaded {} recipes from external API", savedRecipes.size());
            
            // Index recipes for search after saving
            recipeSearchRepository.indexAllRecipes();
            log.info("Completed indexing recipes for full-text search");
            
            return savedRecipes.size();
            
        } catch (Exception e) {
            log.error("Failed to load recipes from external API", e);
            throw new RecipeServiceException("Failed to load recipes from external API: " + e.getMessage(), e);
        }
    }

    /**
     * Get all recipes with pagination
     * 
     * @param pageable Pagination information
     * @return Paginated recipe search response
     */
    public RecipeSearchResponseDto getAllRecipes(Pageable pageable) {
        log.info("Fetching all recipes with pagination - page: {}, size: {}", 
                pageable.getPageNumber(), pageable.getPageSize());
        
        try {
            Page<Recipe> recipePage = recipeRepository.findAll(pageable);
            List<RecipeResponseDto> recipeDtos = mapperService.toResponseDtoList(recipePage.getContent());
            
            return RecipeSearchResponseDto.builder()
                    .recipes(recipeDtos)
                    .totalElements(recipePage.getTotalElements())
                    .totalPages(recipePage.getTotalPages())
                    .currentPage(recipePage.getNumber())
                    .pageSize(recipePage.getSize())
                    .hasNext(recipePage.hasNext())
                    .hasPrevious(recipePage.hasPrevious())
                    .build();
                    
        } catch (Exception e) {
            log.error("Error fetching all recipes", e);
            throw new RecipeServiceException("Failed to fetch recipes", e);
        }
    }

    /**
     * Search recipes using full-text search
     * 
     * @param searchTerm Search term for name and cuisine
     * @param pageable Pagination information
     * @return Paginated search results
     */
    public RecipeSearchResponseDto searchRecipes(String searchTerm, Pageable pageable) {
        log.info("Searching recipes with term: '{}', page: {}, size: {}", 
                searchTerm, pageable.getPageNumber(), pageable.getPageSize());
        
        try {
            Page<Recipe> recipePage;
            
            if (!StringUtils.hasText(searchTerm)) {
                // If no search term, return all recipes
                recipePage = recipeRepository.findAll(pageable);
            } else {
                // Use full-text search
                recipePage = recipeSearchRepository.searchRecipes(searchTerm.trim(), pageable);
            }
            
            List<RecipeResponseDto> recipeDtos = mapperService.toResponseDtoList(recipePage.getContent());
            
            log.info("Search completed. Found {} total matches, returning {} results", 
                    recipePage.getTotalElements(), recipeDtos.size());
            
            return RecipeSearchResponseDto.builder()
                    .recipes(recipeDtos)
                    .totalElements(recipePage.getTotalElements())
                    .totalPages(recipePage.getTotalPages())
                    .currentPage(recipePage.getNumber())
                    .pageSize(recipePage.getSize())
                    .hasNext(recipePage.hasNext())
                    .hasPrevious(recipePage.hasPrevious())
                    .build();
                    
        } catch (Exception e) {
            log.error("Error searching recipes with term: {}", searchTerm, e);
            throw new RecipeServiceException("Failed to search recipes", e);
        }
    }

    /**
     * Find recipe by ID
     * 
     * @param id Recipe ID
     * @return Recipe response DTO
     */
    public Optional<RecipeResponseDto> findRecipeById(Long id) {
        log.info("Finding recipe by ID: {}", id);
        
        try {
            Optional<Recipe> recipe = recipeRepository.findById(id);
            if (recipe.isPresent()) {
                log.info("Recipe found with ID: {}", id);
                return Optional.of(mapperService.toResponseDto(recipe.get()));
            } else {
                log.info("Recipe not found with ID: {}", id);
                return Optional.empty();
            }
        } catch (Exception e) {
            log.error("Error finding recipe by ID: {}", id, e);
            throw new RecipeServiceException("Failed to find recipe by ID: " + id, e);
        }
    }

    /**
     * Search recipes by cuisine
     * 
     * @param cuisine Cuisine to search for
     * @param pageable Pagination information
     * @return Paginated search results
     */
    public RecipeSearchResponseDto searchByCuisine(String cuisine, Pageable pageable) {
        log.info("Searching recipes by cuisine: '{}', page: {}, size: {}", 
                cuisine, pageable.getPageNumber(), pageable.getPageSize());
        
        try {
            Page<Recipe> recipePage;
            
            if (StringUtils.hasText(cuisine)) {
                recipePage = recipeSearchRepository.searchByCuisine(cuisine.trim(), pageable);
            } else {
                recipePage = recipeRepository.findAll(pageable);
            }
            
            List<RecipeResponseDto> recipeDtos = mapperService.toResponseDtoList(recipePage.getContent());
            
            return RecipeSearchResponseDto.builder()
                    .recipes(recipeDtos)
                    .totalElements(recipePage.getTotalElements())
                    .totalPages(recipePage.getTotalPages())
                    .currentPage(recipePage.getNumber())
                    .pageSize(recipePage.getSize())
                    .hasNext(recipePage.hasNext())
                    .hasPrevious(recipePage.hasPrevious())
                    .build();
                    
        } catch (Exception e) {
            log.error("Error searching recipes by cuisine: {}", cuisine, e);
            throw new RecipeServiceException("Failed to search recipes by cuisine", e);
        }
    }

    /**
     * Search recipes by name
     * 
     * @param name Name to search for
     * @param pageable Pagination information
     * @return Paginated search results
     */
    public RecipeSearchResponseDto searchByName(String name, Pageable pageable) {
        log.info("Searching recipes by name: '{}', page: {}, size: {}", 
                name, pageable.getPageNumber(), pageable.getPageSize());
        
        try {
            Page<Recipe> recipePage;
            
            if (StringUtils.hasText(name)) {
                recipePage = recipeSearchRepository.searchByName(name.trim(), pageable);
            } else {
                recipePage = recipeRepository.findAll(pageable);
            }
            
            List<RecipeResponseDto> recipeDtos = mapperService.toResponseDtoList(recipePage.getContent());
            
            return RecipeSearchResponseDto.builder()
                    .recipes(recipeDtos)
                    .totalElements(recipePage.getTotalElements())
                    .totalPages(recipePage.getTotalPages())
                    .currentPage(recipePage.getNumber())
                    .pageSize(recipePage.getSize())
                    .hasNext(recipePage.hasNext())
                    .hasPrevious(recipePage.hasPrevious())
                    .build();
                    
        } catch (Exception e) {
            log.error("Error searching recipes by name: {}", name, e);
            throw new RecipeServiceException("Failed to search recipes by name", e);
        }
    }

    /**
     * Get recipe statistics
     * 
     * @return Recipe statistics
     */
    public RecipeStatsDto getRecipeStats() {
        log.info("Fetching recipe statistics");
        
        try {
            long totalRecipes = recipeRepository.count();
            
            // You can add more statistics here as needed
            return new RecipeStatsDto(totalRecipes);
            
        } catch (Exception e) {
            log.error("Error fetching recipe statistics", e);
            throw new RecipeServiceException("Failed to fetch recipe statistics", e);
        }
    }

    /**
     * Check if recipes are loaded in the database
     * 
     * @return true if recipes exist, false otherwise
     */
    public boolean areRecipesLoaded() {
        try {
            long count = recipeRepository.count();
            log.info("Recipe count in database: {}", count);
            return count > 0;
        } catch (Exception e) {
            log.error("Error checking if recipes are loaded", e);
            return false;
        }
    }

    /**
     * Refresh search index
     */
    @Transactional
    public void refreshSearchIndex() {
        log.info("Refreshing search index");
        try {
            recipeSearchRepository.indexAllRecipes();
            log.info("Search index refreshed successfully");
        } catch (Exception e) {
            log.error("Error refreshing search index", e);
            throw new RecipeServiceException("Failed to refresh search index", e);
        }
    }

    /**
     * Custom exception for recipe service operations
     */
    public static class RecipeServiceException extends RuntimeException {
        public RecipeServiceException(String message) {
            super(message);
        }
        
        public RecipeServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * DTO for recipe statistics
     */
    public static class RecipeStatsDto {
        private final long totalRecipes;
        
        public RecipeStatsDto(long totalRecipes) {
            this.totalRecipes = totalRecipes;
        }
        
        public long getTotalRecipes() {
            return totalRecipes;
        }
    }
}
