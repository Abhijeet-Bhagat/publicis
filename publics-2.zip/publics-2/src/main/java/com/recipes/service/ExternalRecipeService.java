package com.recipes.service;

import com.recipes.config.RecipeApiProperties;
import com.recipes.dto.external.ExternalRecipeResponse;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;
import reactor.core.publisher.Mono;

import java.time.Duration;

/**
 * Service for fetching recipes from external API
 * 
 * This service handles communication with the external dummyjson.com API
 * with resilience features like circuit breaker and retry mechanisms.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ExternalRecipeService {

    private final WebClient webClient;
    private final RecipeApiProperties recipeApiProperties;

    /**
     * Fetch all recipes from external API with resilience patterns
     * 
     * @return ExternalRecipeResponse containing all recipes
     */
    @CircuitBreaker(name = "recipeService", fallbackMethod = "fallbackGetRecipes")
    @Retry(name = "recipeService")
    public ExternalRecipeResponse fetchAllRecipes() {
        log.info("Fetching recipes from external API: {}", recipeApiProperties.getFullUrl());
        
        try {
            return webClient.get()
                    .uri(recipeApiProperties.getEndpoint())
                    .retrieve()
                    .bodyToMono(ExternalRecipeResponse.class)
                    .timeout(Duration.ofMillis(recipeApiProperties.getTimeout()))
                    .doOnSuccess(response -> log.info("Successfully fetched {} recipes from external API", 
                            response != null && response.getRecipes() != null ? response.getRecipes().size() : 0))
                    .doOnError(error -> log.error("Error fetching recipes from external API", error))
                    .block();
                    
        } catch (Exception e) {
            log.error("Failed to fetch recipes from external API: {}", e.getMessage(), e);
            throw new ExternalApiException("Failed to fetch recipes from external API", e);
        }
    }

    /**
     * Fetch specific number of recipes with pagination
     * 
     * @param limit Number of recipes to fetch
     * @param skip Number of recipes to skip
     * @return ExternalRecipeResponse containing paginated recipes
     */
    @CircuitBreaker(name = "recipeService", fallbackMethod = "fallbackGetRecipesPaginated")
    @Retry(name = "recipeService")
    public ExternalRecipeResponse fetchRecipesPaginated(int limit, int skip) {
        log.info("Fetching {} recipes from external API with skip {}", limit, skip);
        
        try {
            return webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(recipeApiProperties.getEndpoint())
                            .queryParam("limit", limit)
                            .queryParam("skip", skip)
                            .build())
                    .retrieve()
                    .bodyToMono(ExternalRecipeResponse.class)
                    .timeout(Duration.ofMillis(recipeApiProperties.getTimeout()))
                    .doOnSuccess(response -> log.info("Successfully fetched {} recipes (page) from external API", 
                            response != null && response.getRecipes() != null ? response.getRecipes().size() : 0))
                    .doOnError(error -> log.error("Error fetching paginated recipes from external API", error))
                    .block();
                    
        } catch (Exception e) {
            log.error("Failed to fetch paginated recipes from external API: {}", e.getMessage(), e);
            throw new ExternalApiException("Failed to fetch paginated recipes from external API", e);
        }
    }

    /**
     * Fetch recipes asynchronously
     * 
     * @return Mono of ExternalRecipeResponse
     */
    public Mono<ExternalRecipeResponse> fetchAllRecipesAsync() {
        log.info("Fetching recipes asynchronously from external API");
        
        return webClient.get()
                .uri(recipeApiProperties.getEndpoint())
                .retrieve()
                .bodyToMono(ExternalRecipeResponse.class)
                .timeout(Duration.ofMillis(recipeApiProperties.getTimeout()))
                .doOnSuccess(response -> log.info("Successfully fetched {} recipes asynchronously", 
                        response != null && response.getRecipes() != null ? response.getRecipes().size() : 0))
                .doOnError(error -> log.error("Error fetching recipes asynchronously", error))
                .onErrorMap(WebClientException.class, 
                          ex -> new ExternalApiException("Failed to fetch recipes asynchronously", ex));
    }

    /**
     * Test connectivity to external API
     * 
     * @return true if API is accessible, false otherwise
     */
    public boolean testApiConnectivity() {
        try {
            log.info("Testing connectivity to external API");
            
            ExternalRecipeResponse response = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(recipeApiProperties.getEndpoint())
                            .queryParam("limit", 1)
                            .build())
                    .retrieve()
                    .bodyToMono(ExternalRecipeResponse.class)
                    .timeout(Duration.ofMillis(5000)) // Shorter timeout for connectivity test
                    .block();
                    
            boolean isConnected = response != null;
            log.info("API connectivity test result: {}", isConnected ? "SUCCESS" : "FAILED");
            return isConnected;
            
        } catch (Exception e) {
            log.warn("API connectivity test failed: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Fallback method for circuit breaker when fetching all recipes
     */
    public ExternalRecipeResponse fallbackGetRecipes(Exception ex) {
        log.error("Circuit breaker activated - falling back for fetchAllRecipes. Error: {}", ex.getMessage());
        throw new ExternalApiException("External recipe service is currently unavailable. Please try again later.", ex);
    }

    /**
     * Fallback method for circuit breaker when fetching paginated recipes
     */
    public ExternalRecipeResponse fallbackGetRecipesPaginated(int limit, int skip, Exception ex) {
        log.error("Circuit breaker activated - falling back for fetchRecipesPaginated. Error: {}", ex.getMessage());
        throw new ExternalApiException("External recipe service is currently unavailable. Please try again later.", ex);
    }

    /**
     * Custom exception for external API failures
     */
    public static class ExternalApiException extends RuntimeException {
        public ExternalApiException(String message) {
            super(message);
        }
        
        public ExternalApiException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
