package com.recipes.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Recipe entity representing a recipe with full-text search capabilities
 * 
 * This entity is mapped to the H2 database and includes Hibernate Search
 * annotations for full-text search functionality on name and cuisine fields.
 */
@Entity
@Table(name = "recipes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Indexed
@JsonIgnoreProperties(ignoreUnknown = true)
public class Recipe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @FullTextField(analyzer = "standard")
    @Column(nullable = false)
    private String name;

    @ElementCollection
    @CollectionTable(name = "recipe_ingredients", joinColumns = @JoinColumn(name = "recipe_id"))
    @Column(name = "ingredient")
    private List<String> ingredients = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "recipe_instructions", joinColumns = @JoinColumn(name = "recipe_id"))
    @Column(name = "instruction", length = 1000)
    @OrderColumn(name = "instruction_order")
    private List<String> instructions = new ArrayList<>();

    @Column(name = "prep_time_minutes")
    private Integer prepTimeMinutes;

    @Column(name = "cook_time_minutes")
    private Integer cookTimeMinutes;

    @Column(name = "servings")
    private Integer servings;

    @Column(name = "difficulty")
    private String difficulty;

    @FullTextField(analyzer = "standard")
    @Column(name = "cuisine")
    private String cuisine;

    @Column(name = "calories_per_serving")
    private Integer caloriesPerServing;

    @ElementCollection
    @CollectionTable(name = "recipe_tags", joinColumns = @JoinColumn(name = "recipe_id"))
    @Column(name = "tag")
    private List<String> tags = new ArrayList<>();

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "image", length = 500)
    private String image;

    @Column(name = "rating")
    private Double rating;

    @Column(name = "review_count")
    private Integer reviewCount;

    @ElementCollection
    @CollectionTable(name = "recipe_meal_type", joinColumns = @JoinColumn(name = "recipe_id"))
    @Column(name = "meal_type")
    private List<String> mealType = new ArrayList<>();

    /**
     * Convenience method to get total cooking time
     */
    public Integer getTotalTimeMinutes() {
        int prep = prepTimeMinutes != null ? prepTimeMinutes : 0;
        int cook = cookTimeMinutes != null ? cookTimeMinutes : 0;
        return prep + cook;
    }

    /**
     * Builder pattern for creating Recipe instances
     */
    public static class RecipeBuilder {
        private Recipe recipe = new Recipe();

        public RecipeBuilder name(String name) {
            recipe.name = name;
            return this;
        }

        public RecipeBuilder ingredients(List<String> ingredients) {
            recipe.ingredients = ingredients != null ? ingredients : new ArrayList<>();
            return this;
        }

        public RecipeBuilder instructions(List<String> instructions) {
            recipe.instructions = instructions != null ? instructions : new ArrayList<>();
            return this;
        }

        public RecipeBuilder prepTimeMinutes(Integer prepTimeMinutes) {
            recipe.prepTimeMinutes = prepTimeMinutes;
            return this;
        }

        public RecipeBuilder cookTimeMinutes(Integer cookTimeMinutes) {
            recipe.cookTimeMinutes = cookTimeMinutes;
            return this;
        }

        public RecipeBuilder servings(Integer servings) {
            recipe.servings = servings;
            return this;
        }

        public RecipeBuilder difficulty(String difficulty) {
            recipe.difficulty = difficulty;
            return this;
        }

        public RecipeBuilder cuisine(String cuisine) {
            recipe.cuisine = cuisine;
            return this;
        }

        public RecipeBuilder caloriesPerServing(Integer caloriesPerServing) {
            recipe.caloriesPerServing = caloriesPerServing;
            return this;
        }

        public RecipeBuilder tags(List<String> tags) {
            recipe.tags = tags != null ? tags : new ArrayList<>();
            return this;
        }

        public RecipeBuilder userId(Integer userId) {
            recipe.userId = userId;
            return this;
        }

        public RecipeBuilder image(String image) {
            recipe.image = image;
            return this;
        }

        public RecipeBuilder rating(Double rating) {
            recipe.rating = rating;
            return this;
        }

        public RecipeBuilder reviewCount(Integer reviewCount) {
            recipe.reviewCount = reviewCount;
            return this;
        }

        public RecipeBuilder mealType(List<String> mealType) {
            recipe.mealType = mealType != null ? mealType : new ArrayList<>();
            return this;
        }

        public Recipe build() {
            return recipe;
        }
    }

    public static RecipeBuilder builder() {
        return new RecipeBuilder();
    }
}
