package com.recipes.controller;

import com.recipes.dto.response.ApiResponse;
import com.recipes.service.RecipeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for data management operations
 * 
 * This controller provides endpoints for loading and managing recipe data
 * from external sources.
 */
@RestController
@RequestMapping("/api/v1/data")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Data Management", description = "APIs for loading and managing recipe data")
public class DataController {

    private final RecipeService recipeService;

    @Operation(
        summary = "Load recipes from external API",
        description = "Fetch all recipes from the external dummyjson.com API and load them into the in-memory H2 database. This operation will clear existing data and reload fresh data."
    )
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200", 
            description = "Recipes loaded successfully"
        ),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "500", 
            description = "Failed to load recipes from external API"
        )
    })
    @PostMapping("/load-recipes")
    public ResponseEntity<ApiResponse<String>> loadRecipes() {
        log.info("Load recipes request received");
        
        try {
            int loadedCount = recipeService.loadRecipesFromExternalApi();
            String message = String.format("Successfully loaded %d recipes from external API", loadedCount);
            
            log.info(message);
            return ResponseEntity.ok(ApiResponse.success(message, 
                    String.format("%d recipes loaded and indexed for search", loadedCount)));
            
        } catch (Exception e) {
            log.error("Failed to load recipes from external API", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to load recipes: " + e.getMessage()));
        }
    }

    @Operation(
        summary = "Check if recipes are loaded",
        description = "Check if recipes are already loaded in the database"
    )
    @PostMapping("/check-recipes")
    public ResponseEntity<ApiResponse<String>> checkRecipes() {
        log.info("Check recipes request received");
        
        try {
            boolean areLoaded = recipeService.areRecipesLoaded();
            String message = areLoaded ? "Recipes are loaded in the database" : "No recipes found in database";
            
            return ResponseEntity.ok(ApiResponse.success(message, 
                    areLoaded ? "Database contains recipe data" : "Database is empty"));
            
        } catch (Exception e) {
            log.error("Error checking if recipes are loaded", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to check recipes: " + e.getMessage()));
        }
    }

    @Operation(
        summary = "Refresh search index",
        description = "Rebuild the full-text search index for all recipes in the database"
    )
    @PostMapping("/refresh-index")
    public ResponseEntity<ApiResponse<String>> refreshSearchIndex() {
        log.info("Refresh search index request received");
        
        try {
            recipeService.refreshSearchIndex();
            String message = "Search index refreshed successfully";
            
            log.info(message);
            return ResponseEntity.ok(ApiResponse.success(message, "All recipes reindexed for search"));
            
        } catch (Exception e) {
            log.error("Failed to refresh search index", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to refresh search index: " + e.getMessage()));
        }
    }
}
