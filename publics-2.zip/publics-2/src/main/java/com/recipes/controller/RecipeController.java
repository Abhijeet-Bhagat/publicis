package com.recipes.controller;

import com.recipes.dto.response.ApiResponse;
import com.recipes.dto.response.RecipeResponseDto;
import com.recipes.dto.response.RecipeSearchResponseDto;
import com.recipes.service.RecipeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * REST Controller for Recipe Management operations
 * 
 * This controller provides endpoints for searching and retrieving recipes
 * from the in-memory H2 database with full-text search capabilities.
 */
@RestController
@RequestMapping("/api/v1/recipes")
@RequiredArgsConstructor
@Slf4j
@Validated
@Tag(name = "Recipe Management", description = "APIs for recipe search and retrieval operations")
public class RecipeController {

    private final RecipeService recipeService;

    @Operation(
        summary = "Search recipes by name and cuisine",
        description = "Perform full-text search on recipe names and cuisines. Supports pagination and sorting."
    )
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200", 
            description = "Search completed successfully",
            content = @Content(schema = @Schema(implementation = RecipeSearchResponseDto.class))
        ),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "400", 
            description = "Invalid search parameters"
        ),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "500", 
            description = "Internal server error"
        )
    })
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<RecipeSearchResponseDto>> searchRecipes(
            @Parameter(description = "Search term for recipe name and cuisine (minimum 3 characters for optimal results)")
            @RequestParam(value = "q", required = false) 
            @Size(min = 1, max = 100, message = "Search term must be between 1 and 100 characters") 
            String searchTerm,
            
            @Parameter(description = "Page number (0-based)")
            @RequestParam(value = "page", defaultValue = "0") 
            @Min(value = 0, message = "Page number must be non-negative") 
            int page,
            
            @Parameter(description = "Page size (max 100)")
            @RequestParam(value = "size", defaultValue = "20") 
            @Min(value = 1, message = "Page size must be positive")
            int size,
            
            @Parameter(description = "Sort field (name, cuisine, cookTimeMinutes, rating)")
            @RequestParam(value = "sort", defaultValue = "name") 
            String sortBy,
            
            @Parameter(description = "Sort direction (asc, desc)")
            @RequestParam(value = "direction", defaultValue = "asc") 
            String direction) {
        
        log.info("Search request - term: '{}', page: {}, size: {}, sort: {} {}", 
                searchTerm, page, size, sortBy, direction);
        
        try {
            // Validate and limit page size
            size = Math.min(size, 100);
            
            // Create sort direction
            Sort.Direction sortDirection = "desc".equalsIgnoreCase(direction) ? 
                    Sort.Direction.DESC : Sort.Direction.ASC;
            
            // Validate sort field
            String validatedSortBy = validateSortField(sortBy);
            
            // Create pageable
            Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, validatedSortBy));
            
            // Perform search
            RecipeSearchResponseDto results = recipeService.searchRecipes(searchTerm, pageable);
            
            log.info("Search completed - found {} total results", results.getTotalElements());
            
            return ResponseEntity.ok(ApiResponse.success("Search completed successfully", results));
            
        } catch (Exception e) {
            log.error("Error during recipe search", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to search recipes: " + e.getMessage()));
        }
    }

    @Operation(
        summary = "Get all recipes",
        description = "Retrieve all recipes with pagination and sorting support"
    )
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200", 
            description = "Recipes retrieved successfully"
        )
    })
    @GetMapping
    public ResponseEntity<ApiResponse<RecipeSearchResponseDto>> getAllRecipes(
            @Parameter(description = "Page number (0-based)")
            @RequestParam(value = "page", defaultValue = "0") 
            @Min(value = 0, message = "Page number must be non-negative") 
            int page,
            
            @Parameter(description = "Page size (max 100)")
            @RequestParam(value = "size", defaultValue = "20") 
            @Min(value = 1, message = "Page size must be positive")
            int size,
            
            @Parameter(description = "Sort field")
            @RequestParam(value = "sort", defaultValue = "name") 
            String sortBy,
            
            @Parameter(description = "Sort direction (asc, desc)")
            @RequestParam(value = "direction", defaultValue = "asc") 
            String direction) {
        
        log.info("Get all recipes request - page: {}, size: {}, sort: {} {}", 
                page, size, sortBy, direction);
        
        try {
            // Validate and limit page size
            size = Math.min(size, 100);
            
            // Create sort direction
            Sort.Direction sortDirection = "desc".equalsIgnoreCase(direction) ? 
                    Sort.Direction.DESC : Sort.Direction.ASC;
            
            // Validate sort field
            String validatedSortBy = validateSortField(sortBy);
            
            // Create pageable
            Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, validatedSortBy));
            
            // Get all recipes
            RecipeSearchResponseDto results = recipeService.getAllRecipes(pageable);
            
            log.info("Retrieved {} recipes from {} total", 
                    results.getRecipes().size(), results.getTotalElements());
            
            return ResponseEntity.ok(ApiResponse.success("Recipes retrieved successfully", results));
            
        } catch (Exception e) {
            log.error("Error retrieving all recipes", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve recipes: " + e.getMessage()));
        }
    }

    @Operation(
        summary = "Get recipe by ID",
        description = "Retrieve a specific recipe by its unique identifier"
    )
    @ApiResponses(value = {
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200", 
            description = "Recipe found and returned successfully"
        ),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "404", 
            description = "Recipe not found"
        )
    })
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<RecipeResponseDto>> getRecipeById(
            @Parameter(description = "Recipe ID", required = true)
            @PathVariable 
            @Min(value = 1, message = "Recipe ID must be positive") 
            Long id) {
        
        log.info("Get recipe by ID request - ID: {}", id);
        
        try {
            Optional<RecipeResponseDto> recipe = recipeService.findRecipeById(id);
            
            if (recipe.isPresent()) {
                log.info("Recipe found with ID: {}", id);
                return ResponseEntity.ok(ApiResponse.success("Recipe found", recipe.get()));
            } else {
                log.info("Recipe not found with ID: {}", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(ApiResponse.error("Recipe not found with ID: " + id));
            }
            
        } catch (Exception e) {
            log.error("Error retrieving recipe by ID: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve recipe: " + e.getMessage()));
        }
    }

    @Operation(
        summary = "Search recipes by cuisine",
        description = "Find recipes by cuisine type with full-text search capabilities"
    )
    @GetMapping("/cuisine")
    public ResponseEntity<ApiResponse<RecipeSearchResponseDto>> searchByCuisine(
            @Parameter(description = "Cuisine type to search for")
            @RequestParam("type") 
            @Size(min = 1, max = 50, message = "Cuisine type must be between 1 and 50 characters") 
            String cuisine,
            
            @RequestParam(value = "page", defaultValue = "0") 
            @Min(value = 0, message = "Page number must be non-negative") 
            int page,
            
            @RequestParam(value = "size", defaultValue = "20") 
            @Min(value = 1, message = "Page size must be positive")
            int size) {
        
        log.info("Search by cuisine request - cuisine: '{}', page: {}, size: {}", cuisine, page, size);
        
        try {
            size = Math.min(size, 100);
            Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
            
            RecipeSearchResponseDto results = recipeService.searchByCuisine(cuisine, pageable);
            
            return ResponseEntity.ok(ApiResponse.success("Cuisine search completed", results));
            
        } catch (Exception e) {
            log.error("Error searching by cuisine: {}", cuisine, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to search by cuisine: " + e.getMessage()));
        }
    }

    @Operation(
        summary = "Search recipes by name",
        description = "Find recipes by name with full-text search capabilities"
    )
    @GetMapping("/name")
    public ResponseEntity<ApiResponse<RecipeSearchResponseDto>> searchByName(
            @Parameter(description = "Recipe name to search for")
            @RequestParam("q") 
            @Size(min = 1, max = 100, message = "Recipe name must be between 1 and 100 characters") 
            String name,
            
            @RequestParam(value = "page", defaultValue = "0") 
            @Min(value = 0, message = "Page number must be non-negative") 
            int page,
            
            @RequestParam(value = "size", defaultValue = "20") 
            @Min(value = 1, message = "Page size must be positive")
            int size) {
        
        log.info("Search by name request - name: '{}', page: {}, size: {}", name, page, size);
        
        try {
            size = Math.min(size, 100);
            Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
            
            RecipeSearchResponseDto results = recipeService.searchByName(name, pageable);
            
            return ResponseEntity.ok(ApiResponse.success("Name search completed", results));
            
        } catch (Exception e) {
            log.error("Error searching by name: {}", name, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to search by name: " + e.getMessage()));
        }
    }

    @Operation(
        summary = "Get recipe statistics",
        description = "Retrieve statistics about the recipe database"
    )
    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<RecipeService.RecipeStatsDto>> getRecipeStats() {
        log.info("Get recipe statistics request");
        
        try {
            RecipeService.RecipeStatsDto stats = recipeService.getRecipeStats();
            return ResponseEntity.ok(ApiResponse.success("Statistics retrieved successfully", stats));
            
        } catch (Exception e) {
            log.error("Error retrieving recipe statistics", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Failed to retrieve statistics: " + e.getMessage()));
        }
    }

    /**
     * Validate and normalize sort field names
     */
    private String validateSortField(String sortBy) {
        return switch (sortBy.toLowerCase()) {
            case "name" -> "name";
            case "cuisine" -> "cuisine";
            case "cooktimeminutes", "cooktime" -> "cookTimeMinutes";
            case "preptimeminutes", "preptime" -> "prepTimeMinutes";
            case "rating" -> "rating";
            case "difficulty" -> "difficulty";
            case "servings" -> "servings";
            case "calories", "caloriesperserving" -> "caloriesPerServing";
            default -> "name"; // Default fallback
        };
    }
}
