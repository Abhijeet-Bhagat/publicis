package com.recipes.repository;

import com.recipes.entity.Recipe;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.search.mapper.orm.Search;
import org.hibernate.search.mapper.orm.session.SearchSession;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for full-text search operations using Hibernate Search
 * 
 * This repository provides advanced search capabilities using Lucene
 * for full-text search across recipe names and cuisines.
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class RecipeSearchRepository {

    private final EntityManager entityManager;

    /**
     * Perform full-text search on recipe names and cuisines
     * 
     * @param searchTerm The search term to look for
     * @param pageable Pagination information
     * @return Page of recipes matching the search term
     */
    public Page<Recipe> searchRecipes(String searchTerm, Pageable pageable) {
        log.info("Performing full-text search for term: {}", searchTerm);
        
        try {
            SearchSession searchSession = Search.session(entityManager);
            
            // Build the search query
            var searchQuery = searchSession.search(Recipe.class)
                    .where(f -> f.bool()
                            .should(f.match().field("name").matching(searchTerm).boost(2.0f))
                            .should(f.match().field("cuisine").matching(searchTerm).boost(1.5f))
                            .should(f.wildcard().field("name").matching("*" + searchTerm.toLowerCase() + "*"))
                            .should(f.wildcard().field("cuisine").matching("*" + searchTerm.toLowerCase() + "*"))
                    )
                    .sort(f -> f.score().desc()
                            .then(f.field("name").asc()))
                    .toQuery();

            // Get total count
            long totalHits = searchQuery.fetchTotalHitCount();
            
            // Get paginated results
            List<Recipe> recipes = searchQuery
                    .fetchHits((int) pageable.getOffset(), pageable.getPageSize());

            log.info("Full-text search completed. Found {} total matches, returning {} results", 
                    totalHits, recipes.size());
            
            return new PageImpl<>(recipes, pageable, totalHits);
            
        } catch (Exception e) {
            log.error("Error performing full-text search for term: {}", searchTerm, e);
            // Fallback to empty result
            return new PageImpl<>(List.of(), pageable, 0);
        }
    }

    /**
     * Search recipes by name only
     * 
     * @param name The name to search for
     * @param pageable Pagination information
     * @return Page of recipes matching the name
     */
    public Page<Recipe> searchByName(String name, Pageable pageable) {
        log.info("Performing name search for: {}", name);
        
        try {
            SearchSession searchSession = Search.session(entityManager);
            
            var searchQuery = searchSession.search(Recipe.class)
                    .where(f -> f.bool()
                            .should(f.match().field("name").matching(name).boost(2.0f))
                            .should(f.wildcard().field("name").matching("*" + name.toLowerCase() + "*"))
                    )
                    .sort(f -> f.score().desc()
                            .then(f.field("name").asc()))
                    .toQuery();

            long totalHits = searchQuery.fetchTotalHitCount();
            List<Recipe> recipes = searchQuery
                    .fetchHits((int) pageable.getOffset(), pageable.getPageSize());

            return new PageImpl<>(recipes, pageable, totalHits);
            
        } catch (Exception e) {
            log.error("Error performing name search for: {}", name, e);
            return new PageImpl<>(List.of(), pageable, 0);
        }
    }

    /**
     * Search recipes by cuisine only
     * 
     * @param cuisine The cuisine to search for
     * @param pageable Pagination information
     * @return Page of recipes matching the cuisine
     */
    public Page<Recipe> searchByCuisine(String cuisine, Pageable pageable) {
        log.info("Performing cuisine search for: {}", cuisine);
        
        try {
            SearchSession searchSession = Search.session(entityManager);
            
            var searchQuery = searchSession.search(Recipe.class)
                    .where(f -> f.bool()
                            .should(f.match().field("cuisine").matching(cuisine).boost(2.0f))
                            .should(f.wildcard().field("cuisine").matching("*" + cuisine.toLowerCase() + "*"))
                    )
                    .sort(f -> f.score().desc()
                            .then(f.field("cuisine").asc()))
                    .toQuery();

            long totalHits = searchQuery.fetchTotalHitCount();
            List<Recipe> recipes = searchQuery
                    .fetchHits((int) pageable.getOffset(), pageable.getPageSize());

            return new PageImpl<>(recipes, pageable, totalHits);
            
        } catch (Exception e) {
            log.error("Error performing cuisine search for: {}", cuisine, e);
            return new PageImpl<>(List.of(), pageable, 0);
        }
    }

    /**
     * Index all recipes for search
     * This method should be called after loading data to ensure search index is updated
     */
    public void indexAllRecipes() {
        log.info("Starting full reindexing of all recipes");
        
        try {
            SearchSession searchSession = Search.session(entityManager);
            searchSession.massIndexer(Recipe.class)
                    .threadsToLoadObjects(4)
                    .batchSizeToLoadObjects(25)
                    .startAndWait();
            
            log.info("Full reindexing completed successfully");
        } catch (InterruptedException e) {
            log.error("Reindexing was interrupted", e);
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            log.error("Error during reindexing", e);
        }
    }
}
