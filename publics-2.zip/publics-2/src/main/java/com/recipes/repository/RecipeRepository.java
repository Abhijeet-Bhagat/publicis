package com.recipes.repository;

import com.recipes.entity.Recipe;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for Recipe entity
 * 
 * This interface provides data access methods for Recipe entities
 * with additional custom query methods.
 */
@Repository
public interface RecipeRepository extends JpaRepository<Recipe, Long> {
    
    /**
     * Find recipes by cuisine
     */
    Page<Recipe> findByCuisineContainingIgnoreCase(String cuisine, Pageable pageable);
    
    /**
     * Find recipes by name containing search term
     */
    Page<Recipe> findByNameContainingIgnoreCase(String name, Pageable pageable);
    
    /**
     * Find recipes by tags containing specific tag
     */
    @Query("SELECT r FROM Recipe r JOIN r.tags t WHERE LOWER(t) LIKE LOWER(CONCAT('%', :tag, '%'))")
    Page<Recipe> findByTagsContaining(@Param("tag") String tag, Pageable pageable);
    
    /**
     * Find recipes by difficulty level
     */
    Page<Recipe> findByDifficultyIgnoreCase(String difficulty, Pageable pageable);
    
    /**
     * Find recipes by cooking time range
     */
    @Query("SELECT r FROM Recipe r WHERE r.cookTimeMinutes BETWEEN :minTime AND :maxTime")
    Page<Recipe> findByCookTimeMinutesBetween(@Param("minTime") Integer minTime, 
                                             @Param("maxTime") Integer maxTime, 
                                             Pageable pageable);
    
    /**
     * Find recipes by name or cuisine using case-insensitive search
     */
    @Query("SELECT r FROM Recipe r WHERE " +
           "LOWER(r.name) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(r.cuisine) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    Page<Recipe> findByNameOrCuisineContaining(@Param("searchTerm") String searchTerm, Pageable pageable);
    
    /**
     * Find all recipes with pagination
     */
    Page<Recipe> findAll(Pageable pageable);
    
    /**
     * Count all recipes
     */
    long count();
    
    /**
     * Check if recipes exist
     */
    boolean existsById(Long id);
    
    /**
     * Find recipes by multiple criteria
     */
    @Query("SELECT r FROM Recipe r WHERE " +
           "(:name IS NULL OR LOWER(r.name) LIKE LOWER(CONCAT('%', :name, '%'))) AND " +
           "(:cuisine IS NULL OR LOWER(r.cuisine) LIKE LOWER(CONCAT('%', :cuisine, '%'))) AND " +
           "(:difficulty IS NULL OR LOWER(r.difficulty) = LOWER(:difficulty)) AND " +
           "(:maxCookTime IS NULL OR r.cookTimeMinutes <= :maxCookTime)")
    Page<Recipe> findByCriteria(@Param("name") String name,
                               @Param("cuisine") String cuisine,
                               @Param("difficulty") String difficulty,
                               @Param("maxCookTime") Integer maxCookTime,
                               Pageable pageable);
}
