package com.recipes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Main application class for Recipe Management API
 * 
 * This is the entry point for the Spring Boot application that provides
 * REST endpoints for recipe management with H2 in-memory database and
 * full-text search capabilities.
 * 
 * @author Recipe Management Team
 * @version 1.0.0
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class RecipeManagementApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(RecipeManagementApiApplication.class, args);
    }
}
