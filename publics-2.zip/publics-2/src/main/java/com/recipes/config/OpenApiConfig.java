package com.recipes.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * OpenAPI/Swagger configuration
 * 
 * This configuration sets up Swagger documentation for the Recipe API
 * with detailed information about the API endpoints and models.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI recipeManagementOpenAPI() {
        Server devServer = new Server();
        devServer.setUrl("http://localhost:8080");
        devServer.setDescription("Server URL for Development environment");

        Contact contact = new Contact();
        contact.setEmail("recipes@example.com");
        contact.setName("Recipe Management Team");
        contact.setUrl("https://github.com/recipe-management");

        License mitLicense = new License()
                .name("MIT License")
                .url("https://choosealicense.com/licenses/mit/");

        Info info = new Info()
                .title("Recipe Management API")
                .version("1.0.0")
                .contact(contact)
                .description("RESTful API for managing recipes with full-text search capabilities. " +
                           "This API provides endpoints to load recipes from external sources, " +
                           "store them in an in-memory H2 database, and perform advanced search operations.")
                .termsOfService("https://example.com/terms")
                .license(mitLicense);

        return new OpenAPI()
                .info(info)
                .servers(List.of(devServer));
    }
}
