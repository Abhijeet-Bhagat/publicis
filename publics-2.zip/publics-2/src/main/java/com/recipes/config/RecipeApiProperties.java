package com.recipes.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Configuration properties for external recipe API
 * 
 * This class holds configuration values for connecting to the
 * external recipes API including timeouts and retry settings.
 */
@Component
@ConfigurationProperties(prefix = "recipes.api")
public class RecipeApiProperties {
    
    private String baseUrl = "https://dummyjson.com";
    private String endpoint = "/recipes";
    private int timeout = 30000;
    private RetryConfig retry = new RetryConfig();
    
    // Getters and Setters
    public String getBaseUrl() {
        return baseUrl;
    }
    
    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }
    
    public String getEndpoint() {
        return endpoint;
    }
    
    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }
    
    public int getTimeout() {
        return timeout;
    }
    
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }
    
    public RetryConfig getRetry() {
        return retry;
    }
    
    public void setRetry(RetryConfig retry) {
        this.retry = retry;
    }
    
    /**
     * Full URL for the recipes API
     */
    public String getFullUrl() {
        return baseUrl + endpoint;
    }
    
    /**
     * Inner class for retry configuration
     */
    public static class RetryConfig {
        private int maxAttempts = 3;
        private long delay = 1000;
        
        public int getMaxAttempts() {
            return maxAttempts;
        }
        
        public void setMaxAttempts(int maxAttempts) {
            this.maxAttempts = maxAttempts;
        }
        
        public long getDelay() {
            return delay;
        }
        
        public void setDelay(long delay) {
            this.delay = delay;
        }
    }
}
