package com.recipes.dto.external;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

/**
 * DTO for external API response from dummyjson.com/recipes
 * 
 * This class represents the structure of the JSON response received
 * from the external recipes API.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExternalRecipeResponse {
    
    private List<ExternalRecipeDto> recipes;
    private Integer total;
    private Integer skip;
    private Integer limit;
}
