package com.recipes.dto.external;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

/**
 * DTO for individual recipe from external API
 * 
 * This class maps the structure of individual recipe objects
 * received from the dummyjson.com API.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExternalRecipeDto {
    
    private Long id;
    private String name;
    private List<String> ingredients;
    private List<String> instructions;
    private Integer prepTimeMinutes;
    private Integer cookTimeMinutes;
    private Integer servings;
    private String difficulty;
    private String cuisine;
    private Integer caloriesPerServing;
    private List<String> tags;
    private Integer userId;
    private String image;
    private Double rating;
    private Integer reviewCount;
    private List<String> mealType;
}
