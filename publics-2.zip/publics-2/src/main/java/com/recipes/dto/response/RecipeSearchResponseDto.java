package com.recipes.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for paginated recipe search responses
 * 
 * This class wraps the search results with pagination information.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecipeSearchResponseDto {
    
    private List<RecipeResponseDto> recipes;
    private Long totalElements;
    private Integer totalPages;
    private Integer currentPage;
    private Integer pageSize;
    private Boolean hasNext;
    private Boolean hasPrevious;
    
    /**
     * Builder pattern for creating search response
     */
    public static class Builder {
        private RecipeSearchResponseDto response = new RecipeSearchResponseDto();
        
        public Builder recipes(List<RecipeResponseDto> recipes) {
            response.recipes = recipes;
            return this;
        }
        
        public Builder totalElements(Long totalElements) {
            response.totalElements = totalElements;
            return this;
        }
        
        public Builder totalPages(Integer totalPages) {
            response.totalPages = totalPages;
            return this;
        }
        
        public Builder currentPage(Integer currentPage) {
            response.currentPage = currentPage;
            return this;
        }
        
        public Builder pageSize(Integer pageSize) {
            response.pageSize = pageSize;
            return this;
        }
        
        public Builder hasNext(Boolean hasNext) {
            response.hasNext = hasNext;
            return this;
        }
        
        public Builder hasPrevious(Boolean hasPrevious) {
            response.hasPrevious = hasPrevious;
            return this;
        }
        
        public RecipeSearchResponseDto build() {
            return response;
        }
    }
    
    public static Builder builder() {
        return new Builder();
    }
}
