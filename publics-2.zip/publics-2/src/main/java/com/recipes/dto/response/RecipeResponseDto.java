package com.recipes.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for Recipe API responses
 * 
 * This class represents the structure of recipe data returned
 * by the internal API endpoints.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecipeResponseDto {
    
    private Long id;
    private String name;
    private List<String> ingredients;
    private List<String> instructions;
    private Integer prepTimeMinutes;
    private Integer cookTimeMinutes;
    private Integer totalTimeMinutes;
    private Integer servings;
    private String difficulty;
    private String cuisine;
    private Integer caloriesPerServing;
    private List<String> tags;
    private Integer userId;
    private String image;
    private Double rating;
    private Integer reviewCount;
    private List<String> mealType;
}
