package com.recipes.controller;

import com.recipes.dto.response.ApiResponse;
import com.recipes.dto.response.RecipeResponseDto;
import com.recipes.dto.response.RecipeSearchResponseDto;
import com.recipes.service.RecipeService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for RecipeController
 */
@WebMvcTest(RecipeController.class)
class RecipeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RecipeService recipeService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testSearchRecipes_WithValidSearchTerm_ShouldReturnResults() throws Exception {
        // Given
        RecipeResponseDto recipe = createRecipeResponseDto(1L, "Pasta Carbonara");
        RecipeSearchResponseDto searchResponse = RecipeSearchResponseDto.builder()
                .recipes(Arrays.asList(recipe))
                .totalElements(1L)
                .totalPages(1)
                .currentPage(0)
                .pageSize(20)
                .hasNext(false)
                .hasPrevious(false)
                .build();

        when(recipeService.searchRecipes(eq("pasta"), any(Pageable.class)))
                .thenReturn(searchResponse);

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/search")
                        .param("q", "pasta")
                        .param("page", "0")
                        .param("size", "20")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Search completed successfully"))
                .andExpect(jsonPath("$.data.recipes").isArray())
                .andExpect(jsonPath("$.data.recipes[0].id").value(1))
                .andExpect(jsonPath("$.data.recipes[0].name").value("Pasta Carbonara"))
                .andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.currentPage").value(0));
    }

    @Test
    void testSearchRecipes_WithoutSearchTerm_ShouldReturnAllRecipes() throws Exception {
        // Given
        RecipeResponseDto recipe1 = createRecipeResponseDto(1L, "Recipe 1");
        RecipeResponseDto recipe2 = createRecipeResponseDto(2L, "Recipe 2");
        RecipeSearchResponseDto searchResponse = RecipeSearchResponseDto.builder()
                .recipes(Arrays.asList(recipe1, recipe2))
                .totalElements(2L)
                .totalPages(1)
                .currentPage(0)
                .pageSize(20)
                .hasNext(false)
                .hasPrevious(false)
                .build();

        when(recipeService.searchRecipes(isNull(), any(Pageable.class)))
                .thenReturn(searchResponse);

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/search")
                        .param("page", "0")
                        .param("size", "20")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.recipes").isArray())
                .andExpect(jsonPath("$.data.recipes.length()").value(2))
                .andExpect(jsonPath("$.data.totalElements").value(2));
    }

    @Test
    void testSearchRecipes_WithInvalidPageSize_ShouldLimitTo100() throws Exception {
        // Given
        RecipeSearchResponseDto searchResponse = RecipeSearchResponseDto.builder()
                .recipes(Arrays.asList())
                .totalElements(0L)
                .totalPages(0)
                .currentPage(0)
                .pageSize(100) // Should be limited to 100
                .hasNext(false)
                .hasPrevious(false)
                .build();

        when(recipeService.searchRecipes(anyString(), any(Pageable.class)))
                .thenReturn(searchResponse);

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/search")
                        .param("q", "test")
                        .param("page", "0")
                        .param("size", "200") // Request 200, should be limited to 100
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void testGetRecipeById_ExistingRecipe_ShouldReturnRecipe() throws Exception {
        // Given
        Long recipeId = 1L;
        RecipeResponseDto recipe = createRecipeResponseDto(recipeId, "Test Recipe");

        when(recipeService.findRecipeById(recipeId)).thenReturn(Optional.of(recipe));

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/{id}", recipeId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Recipe found"))
                .andExpect(jsonPath("$.data.id").value(1))
                .andExpect(jsonPath("$.data.name").value("Test Recipe"));
    }

    @Test
    void testGetRecipeById_NonExistingRecipe_ShouldReturn404() throws Exception {
        // Given
        Long recipeId = 999L;

        when(recipeService.findRecipeById(recipeId)).thenReturn(Optional.empty());

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/{id}", recipeId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Recipe not found with ID: " + recipeId));
    }

    @Test
    void testGetRecipeById_InvalidId_ShouldReturnBadRequest() throws Exception {
        // When & Then
        mockMvc.perform(get("/api/v1/recipes/{id}", "invalid")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testGetAllRecipes_ShouldReturnPaginatedResults() throws Exception {
        // Given
        RecipeResponseDto recipe1 = createRecipeResponseDto(1L, "Recipe 1");
        RecipeResponseDto recipe2 = createRecipeResponseDto(2L, "Recipe 2");
        RecipeSearchResponseDto searchResponse = RecipeSearchResponseDto.builder()
                .recipes(Arrays.asList(recipe1, recipe2))
                .totalElements(2L)
                .totalPages(1)
                .currentPage(0)
                .pageSize(20)
                .hasNext(false)
                .hasPrevious(false)
                .build();

        when(recipeService.getAllRecipes(any(Pageable.class))).thenReturn(searchResponse);

        // When & Then
        mockMvc.perform(get("/api/v1/recipes")
                        .param("page", "0")
                        .param("size", "20")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Recipes retrieved successfully"))
                .andExpect(jsonPath("$.data.recipes").isArray())
                .andExpect(jsonPath("$.data.recipes.length()").value(2))
                .andExpect(jsonPath("$.data.totalElements").value(2));
    }

    @Test
    void testSearchByCuisine_WithValidCuisine_ShouldReturnResults() throws Exception {
        // Given
        RecipeResponseDto recipe = createRecipeResponseDto(1L, "Italian Recipe");
        RecipeSearchResponseDto searchResponse = RecipeSearchResponseDto.builder()
                .recipes(Arrays.asList(recipe))
                .totalElements(1L)
                .totalPages(1)
                .currentPage(0)
                .pageSize(20)
                .hasNext(false)
                .hasPrevious(false)
                .build();

        when(recipeService.searchByCuisine(eq("Italian"), any(Pageable.class)))
                .thenReturn(searchResponse);

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/cuisine")
                        .param("type", "Italian")
                        .param("page", "0")
                        .param("size", "20")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Cuisine search completed"))
                .andExpect(jsonPath("$.data.recipes").isArray())
                .andExpect(jsonPath("$.data.recipes[0].name").value("Italian Recipe"));
    }

    @Test
    void testSearchByName_WithValidName_ShouldReturnResults() throws Exception {
        // Given
        RecipeResponseDto recipe = createRecipeResponseDto(1L, "Pasta Carbonara");
        RecipeSearchResponseDto searchResponse = RecipeSearchResponseDto.builder()
                .recipes(Arrays.asList(recipe))
                .totalElements(1L)
                .totalPages(1)
                .currentPage(0)
                .pageSize(20)
                .hasNext(false)
                .hasPrevious(false)
                .build();

        when(recipeService.searchByName(eq("Pasta"), any(Pageable.class)))
                .thenReturn(searchResponse);

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/name")
                        .param("q", "Pasta")
                        .param("page", "0")
                        .param("size", "20")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Name search completed"))
                .andExpect(jsonPath("$.data.recipes").isArray())
                .andExpect(jsonPath("$.data.recipes[0].name").value("Pasta Carbonara"));
    }

    @Test
    void testGetRecipeStats_ShouldReturnStats() throws Exception {
        // Given
        RecipeService.RecipeStatsDto stats = new RecipeService.RecipeStatsDto(42L);

        when(recipeService.getRecipeStats()).thenReturn(stats);

        // When & Then
        mockMvc.perform(get("/api/v1/recipes/stats")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Statistics retrieved successfully"))
                .andExpect(jsonPath("$.data.totalRecipes").value(42));
    }

    // Helper method
    private RecipeResponseDto createRecipeResponseDto(Long id, String name) {
        RecipeResponseDto dto = new RecipeResponseDto();
        dto.setId(id);
        dto.setName(name);
        dto.setCuisine("Italian");
        dto.setDifficulty("Easy");
        dto.setCookTimeMinutes(30);
        dto.setPrepTimeMinutes(15);
        dto.setTotalTimeMinutes(45);
        dto.setServings(4);
        dto.setRating(4.5);
        return dto;
    }
}
