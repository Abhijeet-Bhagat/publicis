package com.recipes.service;

import com.recipes.dto.external.ExternalRecipeDto;
import com.recipes.dto.response.RecipeResponseDto;
import com.recipes.entity.Recipe;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for RecipeMapperService
 */
@ExtendWith(MockitoExtension.class)
class RecipeMapperServiceTest {

    @InjectMocks
    private RecipeMapperService mapperService;

    @Test
    void testToEntity_WithValidExternalDto_ShouldMapCorrectly() {
        // Given
        ExternalRecipeDto externalDto = new ExternalRecipeDto();
        externalDto.setName("Test Recipe");
        externalDto.setCuisine("Italian");
        externalDto.setDifficulty("Easy");
        externalDto.setCookTimeMinutes(30);
        externalDto.setPrepTimeMinutes(15);
        externalDto.setServings(4);
        externalDto.setIngredients(Arrays.asList("ingredient1", "ingredient2"));
        externalDto.setTags(Arrays.asList("tag1", "tag2"));

        // When
        Recipe result = mapperService.toEntity(externalDto);

        // Then
        assertNotNull(result);
        assertEquals("Test Recipe", result.getName());
        assertEquals("Italian", result.getCuisine());
        assertEquals("Easy", result.getDifficulty());
        assertEquals(30, result.getCookTimeMinutes());
        assertEquals(15, result.getPrepTimeMinutes());
        assertEquals(4, result.getServings());
        assertEquals(2, result.getIngredients().size());
        assertEquals(2, result.getTags().size());
    }

    @Test
    void testToEntity_WithNullDto_ShouldReturnNull() {
        // When
        Recipe result = mapperService.toEntity(null);

        // Then
        assertNull(result);
    }

    @Test
    void testToResponseDto_WithValidEntity_ShouldMapCorrectly() {
        // Given
        Recipe entity = Recipe.builder()
                .id(1L)
                .name("Test Recipe")
                .cuisine("Italian")
                .difficulty("Easy")
                .cookTimeMinutes(30)
                .prepTimeMinutes(15)
                .servings(4)
                .ingredients(Arrays.asList("ingredient1", "ingredient2"))
                .tags(Arrays.asList("tag1", "tag2"))
                .build();

        // When
        RecipeResponseDto result = mapperService.toResponseDto(entity);

        // Then
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Test Recipe", result.getName());
        assertEquals("Italian", result.getCuisine());
        assertEquals("Easy", result.getDifficulty());
        assertEquals(30, result.getCookTimeMinutes());
        assertEquals(15, result.getPrepTimeMinutes());
        assertEquals(4, result.getServings());
        assertEquals(45, result.getTotalTimeMinutes()); // prep + cook time
        assertEquals(2, result.getIngredients().size());
        assertEquals(2, result.getTags().size());
    }

    @Test
    void testToResponseDto_WithNullEntity_ShouldReturnNull() {
        // When
        RecipeResponseDto result = mapperService.toResponseDto(null);

        // Then
        assertNull(result);
    }

    @Test
    void testToResponseDtoList_WithValidEntities_ShouldMapAll() {
        // Given
        List<Recipe> entities = Arrays.asList(
                Recipe.builder().id(1L).name("Recipe 1").build(),
                Recipe.builder().id(2L).name("Recipe 2").build()
        );

        // When
        List<RecipeResponseDto> result = mapperService.toResponseDtoList(entities);

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Recipe 1", result.get(0).getName());
        assertEquals("Recipe 2", result.get(1).getName());
    }

    @Test
    void testToResponseDtoList_WithNullList_ShouldReturnEmptyList() {
        // When
        List<RecipeResponseDto> result = mapperService.toResponseDtoList(null);

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testToSummaryDto_WithValidEntity_ShouldMapOnlyEssentialFields() {
        // Given
        Recipe entity = Recipe.builder()
                .id(1L)
                .name("Test Recipe")
                .cuisine("Italian")
                .difficulty("Easy")
                .cookTimeMinutes(30)
                .prepTimeMinutes(15)
                .servings(4)
                .rating(4.5)
                .ingredients(Arrays.asList("ingredient1", "ingredient2", "ingredient3"))
                .instructions(Arrays.asList("step1", "step2", "step3"))
                .build();

        // When
        RecipeResponseDto result = mapperService.toSummaryDto(entity);

        // Then
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Test Recipe", result.getName());
        assertEquals("Italian", result.getCuisine());
        assertEquals("Easy", result.getDifficulty());
        assertEquals(30, result.getCookTimeMinutes());
        assertEquals(15, result.getPrepTimeMinutes());
        assertEquals(45, result.getTotalTimeMinutes());
        assertEquals(4, result.getServings());
        assertEquals(4.5, result.getRating());
        
        // Instructions should not be included in summary
        assertNull(result.getInstructions());
        assertNull(result.getIngredients());
    }
}
