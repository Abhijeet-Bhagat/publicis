package com.recipes.service;

import com.recipes.dto.external.ExternalRecipeDto;
import com.recipes.dto.external.ExternalRecipeResponse;
import com.recipes.dto.response.RecipeResponseDto;
import com.recipes.dto.response.RecipeSearchResponseDto;
import com.recipes.entity.Recipe;
import com.recipes.repository.RecipeRepository;
import com.recipes.repository.RecipeSearchRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for RecipeService
 */
@ExtendWith(MockitoExtension.class)
class RecipeServiceTest {

    @Mock
    private RecipeRepository recipeRepository;

    @Mock
    private RecipeSearchRepository recipeSearchRepository;

    @Mock
    private ExternalRecipeService externalRecipeService;

    @Mock
    private RecipeMapperService mapperService;

    @InjectMocks
    private RecipeService recipeService;

    @Test
    void testLoadRecipesFromExternalApi_Success() {
        // Given
        ExternalRecipeResponse externalResponse = new ExternalRecipeResponse();
        List<ExternalRecipeDto> externalRecipes = Arrays.asList(
                createExternalRecipeDto(1L, "Recipe 1"),
                createExternalRecipeDto(2L, "Recipe 2")
        );
        externalResponse.setRecipes(externalRecipes);

        List<Recipe> recipes = Arrays.asList(
                createRecipe(1L, "Recipe 1"),
                createRecipe(2L, "Recipe 2")
        );

        when(recipeRepository.count()).thenReturn(0L);
        when(externalRecipeService.fetchAllRecipes()).thenReturn(externalResponse);
        when(mapperService.toEntityList(externalRecipes)).thenReturn(recipes);
        when(recipeRepository.saveAll(recipes)).thenReturn(recipes);

        // When
        int result = recipeService.loadRecipesFromExternalApi();

        // Then
        assertEquals(2, result);
        verify(recipeRepository).count();
        verify(externalRecipeService).fetchAllRecipes();
        verify(mapperService).toEntityList(externalRecipes);
        verify(recipeRepository).saveAll(recipes);
        verify(recipeSearchRepository).indexAllRecipes();
    }

    @Test
    void testLoadRecipesFromExternalApi_WithExistingData_ShouldClearFirst() {
        // Given
        ExternalRecipeResponse externalResponse = new ExternalRecipeResponse();
        List<ExternalRecipeDto> externalRecipes = Arrays.asList(createExternalRecipeDto(1L, "Recipe 1"));
        externalResponse.setRecipes(externalRecipes);

        List<Recipe> recipes = Arrays.asList(createRecipe(1L, "Recipe 1"));

        when(recipeRepository.count()).thenReturn(5L);
        when(externalRecipeService.fetchAllRecipes()).thenReturn(externalResponse);
        when(mapperService.toEntityList(externalRecipes)).thenReturn(recipes);
        when(recipeRepository.saveAll(recipes)).thenReturn(recipes);

        // When
        int result = recipeService.loadRecipesFromExternalApi();

        // Then
        assertEquals(1, result);
        verify(recipeRepository).deleteAll(); // Should clear existing data
        verify(recipeRepository).saveAll(recipes);
    }

    @Test
    void testLoadRecipesFromExternalApi_WithNullResponse_ShouldReturn0() {
        // Given
        when(recipeRepository.count()).thenReturn(0L);
        when(externalRecipeService.fetchAllRecipes()).thenReturn(null);

        // When
        int result = recipeService.loadRecipesFromExternalApi();

        // Then
        assertEquals(0, result);
        verify(recipeRepository, never()).saveAll(any());
        verify(recipeSearchRepository, never()).indexAllRecipes();
    }

    @Test
    void testSearchRecipes_WithSearchTerm_ShouldUseFullTextSearch() {
        // Given
        String searchTerm = "pasta";
        Pageable pageable = PageRequest.of(0, 10);
        
        List<Recipe> recipes = Arrays.asList(createRecipe(1L, "Pasta Recipe"));
        Page<Recipe> recipePage = new PageImpl<>(recipes, pageable, 1);
        
        List<RecipeResponseDto> recipeDtos = Arrays.asList(createRecipeResponseDto(1L, "Pasta Recipe"));

        when(recipeSearchRepository.searchRecipes(searchTerm, pageable)).thenReturn(recipePage);
        when(mapperService.toResponseDtoList(recipes)).thenReturn(recipeDtos);

        // When
        RecipeSearchResponseDto result = recipeService.searchRecipes(searchTerm, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getRecipes().size());
        assertEquals(1L, result.getTotalElements());
        assertEquals(0, result.getCurrentPage());
        verify(recipeSearchRepository).searchRecipes(searchTerm, pageable);
        verify(mapperService).toResponseDtoList(recipes);
    }

    @Test
    void testSearchRecipes_WithEmptySearchTerm_ShouldReturnAllRecipes() {
        // Given
        String searchTerm = "";
        Pageable pageable = PageRequest.of(0, 10);
        
        List<Recipe> recipes = Arrays.asList(createRecipe(1L, "Recipe"));
        Page<Recipe> recipePage = new PageImpl<>(recipes, pageable, 1);
        
        List<RecipeResponseDto> recipeDtos = Arrays.asList(createRecipeResponseDto(1L, "Recipe"));

        when(recipeRepository.findAll(pageable)).thenReturn(recipePage);
        when(mapperService.toResponseDtoList(recipes)).thenReturn(recipeDtos);

        // When
        RecipeSearchResponseDto result = recipeService.searchRecipes(searchTerm, pageable);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getRecipes().size());
        verify(recipeRepository).findAll(pageable);
        verify(recipeSearchRepository, never()).searchRecipes(anyString(), any());
    }

    @Test
    void testFindRecipeById_ExistingRecipe_ShouldReturnRecipe() {
        // Given
        Long recipeId = 1L;
        Recipe recipe = createRecipe(recipeId, "Test Recipe");
        RecipeResponseDto recipeDto = createRecipeResponseDto(recipeId, "Test Recipe");

        when(recipeRepository.findById(recipeId)).thenReturn(Optional.of(recipe));
        when(mapperService.toResponseDto(recipe)).thenReturn(recipeDto);

        // When
        Optional<RecipeResponseDto> result = recipeService.findRecipeById(recipeId);

        // Then
        assertTrue(result.isPresent());
        assertEquals(recipeId, result.get().getId());
        assertEquals("Test Recipe", result.get().getName());
        verify(recipeRepository).findById(recipeId);
        verify(mapperService).toResponseDto(recipe);
    }

    @Test
    void testFindRecipeById_NonExistingRecipe_ShouldReturnEmpty() {
        // Given
        Long recipeId = 999L;

        when(recipeRepository.findById(recipeId)).thenReturn(Optional.empty());

        // When
        Optional<RecipeResponseDto> result = recipeService.findRecipeById(recipeId);

        // Then
        assertFalse(result.isPresent());
        verify(recipeRepository).findById(recipeId);
        verify(mapperService, never()).toResponseDto(any());
    }

    @Test
    void testGetRecipeStats_ShouldReturnCorrectStats() {
        // Given
        long totalRecipes = 42L;
        when(recipeRepository.count()).thenReturn(totalRecipes);

        // When
        RecipeService.RecipeStatsDto result = recipeService.getRecipeStats();

        // Then
        assertNotNull(result);
        assertEquals(totalRecipes, result.getTotalRecipes());
        verify(recipeRepository).count();
    }

    @Test
    void testAreRecipesLoaded_WithRecipes_ShouldReturnTrue() {
        // Given
        when(recipeRepository.count()).thenReturn(5L);

        // When
        boolean result = recipeService.areRecipesLoaded();

        // Then
        assertTrue(result);
        verify(recipeRepository).count();
    }

    @Test
    void testAreRecipesLoaded_WithoutRecipes_ShouldReturnFalse() {
        // Given
        when(recipeRepository.count()).thenReturn(0L);

        // When
        boolean result = recipeService.areRecipesLoaded();

        // Then
        assertFalse(result);
        verify(recipeRepository).count();
    }

    @Test
    void testRefreshSearchIndex_ShouldCallIndexAllRecipes() {
        // When
        recipeService.refreshSearchIndex();

        // Then
        verify(recipeSearchRepository).indexAllRecipes();
    }

    // Helper methods
    private ExternalRecipeDto createExternalRecipeDto(Long id, String name) {
        ExternalRecipeDto dto = new ExternalRecipeDto();
        dto.setId(id);
        dto.setName(name);
        dto.setCuisine("Italian");
        dto.setDifficulty("Easy");
        return dto;
    }

    private Recipe createRecipe(Long id, String name) {
        return Recipe.builder()
                .id(id)
                .name(name)
                .cuisine("Italian")
                .difficulty("Easy")
                .cookTimeMinutes(30)
                .prepTimeMinutes(15)
                .build();
    }

    private RecipeResponseDto createRecipeResponseDto(Long id, String name) {
        RecipeResponseDto dto = new RecipeResponseDto();
        dto.setId(id);
        dto.setName(name);
        dto.setCuisine("Italian");
        dto.setDifficulty("Easy");
        dto.setCookTimeMinutes(30);
        dto.setPrepTimeMinutes(15);
        dto.setTotalTimeMinutes(45);
        return dto;
    }
}
