# Recipe Management API

A production-ready RESTful API for managing recipes with full-text search capabilities, built with Spring Boot 3, H2 in-memory database, and Hibernate Search.

## 🚀 Features

- **External Data Loading**: Load recipes from external API (dummyjson.com/recipes)
- **Full-Text Search**: Advanced search using Hibernate Search with Lucene
- **REST API**: Comprehensive CRUD operations with pagination
- **In-Memory Database**: H2 database for fast data access
- **Resilience**: Circuit breaker and retry patterns for external API calls
- **API Documentation**: Complete Swagger/OpenAPI documentation
- **Production Ready**: Comprehensive error handling, logging, and testing

## 📋 Table of Contents

- [Quick Start](#quick-start)
- [API Endpoints](#api-endpoints)
- [Architecture](#architecture)
- [Configuration](#configuration)
- [Testing](#testing)
- [Development](#development)
- [Deployment](#deployment)

## 🏃‍♂️ Quick Start

### Prerequisites

- Java 17 or higher
- Maven 3.6+
- Internet connection (for loading external recipe data)

### Running the Application

1. **Clone and navigate to the project directory**
   ```bash
   cd recipe-management-api
   ```

2. **Build the application**
   ```bash
   mvn clean compile
   ```

3. **Run the application**
   ```bash
   mvn spring-boot:run
   ```

4. **Load recipe data** (first-time setup)
   ```bash
   curl -X POST http://localhost:8080/api/v1/data/load-recipes
   ```

5. **Access the application**
   - API Base URL: `http://localhost:8080/api/v1`
   - Swagger UI: `http://localhost:8080/swagger-ui.html`
   - H2 Console: `http://localhost:8080/h2-console`

## 📚 API Endpoints

### Data Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/data/load-recipes` | Load all recipes from external API |
| POST | `/api/v1/data/check-recipes` | Check if recipes are loaded |
| POST | `/api/v1/data/refresh-index` | Refresh search index |

### Recipe Operations

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/recipes` | Get all recipes with pagination |
| GET | `/api/v1/recipes/search` | Search recipes by name and cuisine |
| GET | `/api/v1/recipes/{id}` | Get recipe by ID |
| GET | `/api/v1/recipes/cuisine` | Search recipes by cuisine |
| GET | `/api/v1/recipes/name` | Search recipes by name |
| GET | `/api/v1/recipes/stats` | Get recipe statistics |

### Query Parameters

- `q` - Search term (minimum 3 characters recommended)
- `page` - Page number (0-based, default: 0)
- `size` - Page size (1-100, default: 20)
- `sort` - Sort field (name, cuisine, cookTimeMinutes, rating)
- `direction` - Sort direction (asc, desc, default: asc)

### Example API Calls

```bash
# Load recipes from external API
curl -X POST http://localhost:8080/api/v1/data/load-recipes

# Search for pasta recipes
curl "http://localhost:8080/api/v1/recipes/search?q=pasta&page=0&size=10"

# Get recipe by ID
curl http://localhost:8080/api/v1/recipes/1

# Search by cuisine
curl "http://localhost:8080/api/v1/recipes/cuisine?type=Italian&page=0&size=20"

# Get all recipes with sorting
curl "http://localhost:8080/api/v1/recipes?page=0&size=20&sort=cookTimeMinutes&direction=asc"
```

## 🏗️ Architecture

### Technology Stack

- **Framework**: Spring Boot 3.2.0
- **Database**: H2 In-Memory Database
- **Search**: Hibernate Search 6.2.0 with Lucene
- **HTTP Client**: Spring WebFlux WebClient
- **Resilience**: Resilience4j Circuit Breaker & Retry
- **Documentation**: SpringDoc OpenAPI 3
- **Testing**: JUnit 5, Mockito, Spring Boot Test

### Project Structure

```
src/
├── main/
│   ├── java/com/recipes/
│   │   ├── config/          # Configuration classes
│   │   ├── controller/      # REST controllers
│   │   ├── dto/            # Data Transfer Objects
│   │   ├── entity/         # JPA entities
│   │   ├── exception/      # Exception handling
│   │   ├── repository/     # Data access layer
│   │   └── service/        # Business logic
│   └── resources/
│       └── application.properties
└── test/                   # Unit and integration tests
```

### Key Components

1. **RecipeController**: REST API endpoints
2. **RecipeService**: Business logic and orchestration
3. **ExternalRecipeService**: External API integration with resilience
4. **RecipeSearchRepository**: Full-text search implementation
5. **Recipe Entity**: JPA entity with Hibernate Search annotations

## ⚙️ Configuration

### Application Properties

Key configuration options in `application.properties`:

```properties
# Server Configuration
server.port=8080

# Database Configuration
spring.datasource.url=jdbc:h2:mem:recipedb
spring.h2.console.enabled=true

# External API Configuration
recipes.api.base-url=https://dummyjson.com
recipes.api.timeout=30000

# Search Configuration
spring.jpa.properties.hibernate.search.backend.type=lucene

# Circuit Breaker Configuration
resilience4j.circuitbreaker.instances.recipeService.slidingWindowSize=10
resilience4j.circuitbreaker.instances.recipeService.failureRateThreshold=50
```

### Environment Variables

You can override configuration using environment variables:

```bash
export SERVER_PORT=8081
export RECIPES_API_BASE_URL=https://alternative-api.com
export RECIPES_API_TIMEOUT=60000
```

## 🧪 Testing

### Run All Tests

```bash
mvn test
```

### Run with Coverage

```bash
mvn test jacoco:report
```

View coverage report: `target/site/jacoco/index.html`

### Test Categories

- **Unit Tests**: Service and repository layer tests
- **Integration Tests**: Controller and API endpoint tests
- **Test Coverage**: Comprehensive coverage of business logic

### Example Test Execution

```bash
# Run specific test class
mvn test -Dtest=RecipeServiceTest

# Run tests with specific profile
mvn test -Dspring.profiles.active=test
```

## 🔧 Development

### Development Workflow

1. **Setup Development Environment**
   ```bash
   # Install dependencies
   mvn clean install
   
   # Run in development mode
   mvn spring-boot:run -Dspring-boot.run.profiles=dev
   ```

2. **Database Access**
   - H2 Console: `http://localhost:8080/h2-console`
   - JDBC URL: `jdbc:h2:mem:recipedb`
   - Username: `sa`
   - Password: `password`

3. **API Documentation**
   - Swagger UI: `http://localhost:8080/swagger-ui.html`
   - OpenAPI JSON: `http://localhost:8080/api-docs`

### Code Quality

- **Formatting**: Follow Google Java Style Guide
- **Logging**: Use SLF4J with appropriate log levels
- **Error Handling**: Comprehensive exception handling with meaningful messages
- **Validation**: Input validation with Bean Validation

### Adding New Features

1. Create feature branch: `git checkout -b feature/new-feature`
2. Implement changes with tests
3. Run quality checks: `mvn clean verify`
4. Create pull request

## 🚀 Deployment

### Production Build

```bash
# Create production JAR
mvn clean package -Pprod

# Run production JAR
java -jar target/recipe-management-api-1.0.0.jar
```

### Docker Deployment

```dockerfile
FROM openjdk:17-jre-slim
COPY target/recipe-management-api-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

### Health Checks

The application includes actuator endpoints for monitoring:

- Health: `http://localhost:8080/actuator/health`
- Metrics: `http://localhost:8080/actuator/metrics`
- Info: `http://localhost:8080/actuator/info`

### Production Considerations

1. **Database**: Replace H2 with persistent database (PostgreSQL, MySQL)
2. **Security**: Add authentication and authorization
3. **Monitoring**: Integrate with APM tools (Micrometer, Prometheus)
4. **Caching**: Add Redis for caching frequently accessed data
5. **Load Balancing**: Deploy multiple instances behind load balancer

## 📊 Performance

### Search Performance

- **Full-text search**: Sub-second response times for typical queries
- **Indexing**: Automatic indexing after data loading
- **Pagination**: Efficient pagination for large result sets

### API Performance

- **Response Times**: < 100ms for typical recipe queries
- **Throughput**: Supports hundreds of concurrent requests
- **Memory Usage**: Optimized for minimal memory footprint

## 🔍 Troubleshooting

### Common Issues

1. **External API Timeout**
   ```
   Solution: Check internet connectivity and external API status
   Configuration: Increase recipes.api.timeout value
   ```

2. **Search Index Issues**
   ```
   Solution: Call POST /api/v1/data/refresh-index
   Check: Lucene index directory permissions
   ```

3. **Memory Issues**
   ```
   Solution: Increase JVM heap size: -Xmx2g
   Monitor: Use actuator/metrics endpoints
   ```

### Logging

Enable debug logging for troubleshooting:

```properties
logging.level.com.recipes=DEBUG
logging.level.org.hibernate.search=DEBUG
```

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Follow coding standards
4. Add comprehensive tests
5. Update documentation
6. Submit pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Support

For support and questions:

- Create an issue in the repository
- Check existing documentation
- Review API documentation in Swagger UI

---

## 🎯 Next Steps (Frontend Integration)

This backend API is designed to work with a React/Angular frontend. The API provides:

- **CORS enabled** for frontend integration
- **Consistent response format** for easy consumption
- **Comprehensive error handling** with meaningful error codes
- **Pagination support** for efficient data loading
- **Search capabilities** for dynamic filtering

Recommended frontend features:
- Global search bar with autocomplete
- Recipe grid with sorting and filtering
- Recipe detail views
- Responsive design for mobile devices
- Client-side caching for performance

Ready to integrate with your frontend application! 🚀
