#!/bin/bash

# Recipe Management API - Build and Run Script

echo "🍳 Recipe Management API Setup"
echo "================================"

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "❌ Java is not installed. Please install Java 17 or higher."
    echo "   On macOS: brew install openjdk@17"
    echo "   On Ubuntu: sudo apt install openjdk-17-jdk"
    exit 1
fi

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "❌ Maven is not installed. Please install Maven."
    echo "   On macOS: brew install maven"
    echo "   On Ubuntu: sudo apt install maven"
    exit 1
fi

echo "✅ Java version:"
java -version

echo "✅ Maven version:"
mvn -version

echo ""
echo "📦 Building the application..."
mvn clean compile

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo ""
    echo "🚀 Starting the Recipe Management API..."
    echo "   The API will be available at: http://localhost:8080"
    echo "   Swagger UI will be available at: http://localhost:8080/swagger-ui.html"
    echo "   H2 Console will be available at: http://localhost:8080/h2-console"
    echo ""
    echo "📋 After the application starts, load recipe data by calling:"
    echo "   curl -X POST http://localhost:8080/api/v1/data/load-recipes"
    echo ""
    echo "Press Ctrl+C to stop the application"
    echo ""
    
    mvn spring-boot:run
else
    echo "❌ Build failed. Please check the error messages above."
    exit 1
fi
