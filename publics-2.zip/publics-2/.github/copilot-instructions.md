<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Recipe Management API - Copilot Instructions

## Project Overview
This is a production-ready Spring Boot 3 REST API for recipe management with the following key features:
- External data loading from dummyjson.com/recipes API
- H2 in-memory database for fast development and testing
- Hibernate Search with Lucene for full-text search
- Resilience patterns (Circuit Breaker, Retry) for external API calls
- Comprehensive error handling and validation
- Complete Swagger/OpenAPI documentation
- Extensive unit and integration testing

## Code Standards and Practices

### Architecture Patterns
- **Layered Architecture**: Controller → Service → Repository → Entity
- **DTOs**: Separate DTOs for external APIs, responses, and internal mapping
- **Builder Pattern**: Used in entities and response DTOs for clean object creation
- **Repository Pattern**: JPA repositories with custom query methods
- **Service Layer**: Business logic separation with clear responsibilities

### Spring Boot Best Practices
- Use `@RestController` for REST endpoints
- Use `@Service`, `@Repository`, `@Component` for proper component scanning
- Leverage Spring Boot auto-configuration where possible
- Use `@ConfigurationProperties` for external configuration
- Implement proper exception handling with `@RestControllerAdvice`

### Database and Search
- Use JPA/Hibernate with proper entity relationships
- Implement Hibernate Search annotations (`@Indexed`, `@FullTextField`) for search
- Use `@Transactional` for service methods that modify data
- Leverage H2 for development, but design for production database compatibility

### API Design
- Follow REST principles and HTTP status codes
- Use consistent response format with `ApiResponse<T>` wrapper
- Implement proper pagination with Spring Data `Pageable`
- Use Bean Validation (`@Valid`, `@Size`, `@Min`) for input validation
- Design APIs with versioning in mind (`/api/v1/`)

### Error Handling
- Use global exception handler for consistent error responses
- Provide meaningful error messages and error codes
- Log errors appropriately with different log levels
- Handle external API failures gracefully with fallback mechanisms

### Testing Strategy
- Write comprehensive unit tests for service layer
- Use integration tests for controller layer with `@WebMvcTest`
- Mock external dependencies properly with Mockito
- Aim for high test coverage especially on business logic
- Use test data builders for clean test setup

### Configuration Management
- Use `application.properties` for configuration
- Support environment-specific configurations
- Use `@ConfigurationProperties` for type-safe configuration binding
- Document all configuration options in README

### Logging and Monitoring
- Use SLF4J for logging with appropriate log levels
- Include correlation information in logs for tracing
- Use Spring Boot Actuator for health checks and metrics
- Log performance-critical operations with timing information

## Code Style Guidelines

### Naming Conventions
- **Classes**: PascalCase (e.g., `RecipeService`, `ExternalRecipeDto`)
- **Methods**: camelCase (e.g., `findRecipeById`, `loadRecipesFromExternalApi`)
- **Variables**: camelCase (e.g., `searchTerm`, `recipeRepository`)
- **Constants**: UPPER_SNAKE_CASE (e.g., `DEFAULT_PAGE_SIZE`)
- **Packages**: lowercase with dots (e.g., `com.recipes.service`)

### Documentation
- Use JavaDoc for public APIs and complex methods
- Include parameter descriptions and return value documentation
- Document any non-obvious business logic or algorithms
- Keep comments up-to-date with code changes

### Package Organization
```
com.recipes/
├── config/          # Configuration classes
├── controller/      # REST controllers
├── dto/            # Data Transfer Objects
│   ├── external/   # External API DTOs
│   └── response/   # API response DTOs
├── entity/         # JPA entities
├── exception/      # Exception classes
├── repository/     # Data access layer
└── service/        # Business logic
```

## Common Patterns in This Codebase

### Service Methods
```java
public RecipeSearchResponseDto searchRecipes(String searchTerm, Pageable pageable) {
    log.info("Searching recipes with term: '{}'", searchTerm);
    try {
        // Business logic here
        return result;
    } catch (Exception e) {
        log.error("Error searching recipes", e);
        throw new RecipeServiceException("Failed to search recipes", e);
    }
}
```

### Controller Methods
```java
@GetMapping("/search")
public ResponseEntity<ApiResponse<RecipeSearchResponseDto>> searchRecipes(
        @RequestParam(value = "q", required = false) String searchTerm,
        @RequestParam(value = "page", defaultValue = "0") int page) {
    try {
        // Delegate to service
        RecipeSearchResponseDto results = recipeService.searchRecipes(searchTerm, pageable);
        return ResponseEntity.ok(ApiResponse.success("Search completed", results));
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiResponse.error("Failed to search recipes: " + e.getMessage()));
    }
}
```

### Entity Definitions
```java
@Entity
@Table(name = "recipes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Indexed
public class Recipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @FullTextField(analyzer = "standard")
    @Column(nullable = false)
    private String name;
    // ... other fields
}
```

## Integration Points

### External API Integration
- Use WebClient for reactive HTTP calls
- Implement circuit breaker and retry patterns
- Handle timeouts and connection failures gracefully
- Map external DTOs to internal entities using dedicated mapper service

### Search Integration
- Use Hibernate Search for full-text search capabilities
- Index entities automatically on data changes
- Provide search methods in dedicated search repository
- Support advanced search queries with scoring and sorting

### Database Integration
- Use Spring Data JPA for data access
- Implement custom queries when needed
- Use proper transaction boundaries
- Support pagination for large datasets

## When Adding New Features

1. **Add DTOs first** if new data structures are needed
2. **Extend entities** with proper JPA annotations
3. **Add repository methods** for new data access patterns
4. **Implement service logic** with proper error handling
5. **Create controller endpoints** with validation
6. **Add comprehensive tests** for new functionality
7. **Update documentation** including README and API docs

## Performance Considerations

- Use pagination for all list endpoints
- Implement proper indexing for search functionality
- Cache frequently accessed data when appropriate
- Monitor external API call performance and timeouts
- Use connection pooling for database and HTTP connections

## Security Considerations

- Validate all inputs using Bean Validation
- Sanitize search terms to prevent injection attacks
- Implement proper error handling that doesn't leak system information
- Use parameterized queries to prevent SQL injection
- Plan for authentication and authorization in future iterations
